<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage modus
 * @since modus 1.0
 */
?>

<?php if ( is_active_sidebar( 'general-sidebar' )  ) : ?>
	<aside id="secondary" class="sidebar widget-area">
		<?php dynamic_sidebar( 'general-sidebar' ); ?>
	</aside><!-- .sidebar .widget-area -->
<?php endif; ?>
