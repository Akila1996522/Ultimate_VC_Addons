jQuery(function($){
    jQuery('.modus-counter').each(function() {
        jQuery('.item_counter').each(function() {
            $(this).bsf_appear(function() {
                var endNum = parseFloat(jQuery(this).find('.stats-number').data('counter-value'));
                var Num = (jQuery(this).find('.stats-number').data('counter-value'))+' ';
                var speed = parseInt(jQuery(this).find('.stats-number').data('speed'));
                var ID = jQuery(this).find('.stats-number').data('id');
                var sep = jQuery(this).find('.stats-number').data('separator');
                var dec = jQuery(this).find('.stats-number').data('decimal');
                var dec_count = Num.split(".");
                if(dec_count[1]){
                    dec_count = dec_count[1].length-1;
                } else {
                    dec_count = 0;
                }
                var grouping = true;
                if(dec == "none"){
                    dec = "";
                }
                if(sep == "none"){
                    grouping = false;
                } else {
                    grouping = true;
                }
                var settings = {
                    useEasing : true,
                    useGrouping : grouping,
                    separator : sep,
                    decimal : dec
                }
                var counter = new countUp(ID, 0, endNum, dec_count, speed, settings);
                setTimeout(function(){
                    counter.start();
                },500);
            });
        });
    });
})
