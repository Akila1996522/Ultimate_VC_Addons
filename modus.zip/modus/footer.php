<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Modus
 * @since Modus 1.0
 */
        global $post;
        $modus_show_footer=true;
        if( is_page() && get_post_meta( $post->ID, 'hidden_footer', true ) && get_post_meta($post->ID, 'hidden_footer', true)== 'hidden_footer' ){
            $modus_show_footer=false;
        }
        if ( $modus_show_footer ){
        ?>
        <footer id="colophon" class="site-footer">
            <?php
                modus_footer_types();
            ?>
        </footer><!-- .site-footer -->
        <?php } ?>
		</div><!-- .site-content -->
    </div><!-- .site-inner -->
    <a class="scroll-to-top"><i class="fa fa-arrow-up"></i></a>
    <div class="div-close-menu au-close-menu"></div>
</div><!-- .site -->

<?php wp_footer(); ?>
</body>
</html>
