<?php
get_header();
$modus_config = modus_settings();
$modus_layout_single_port = '';
if ( isset( $_GET['layout_single'] ) ){
    $modus_layout_single_port = $_GET['layout_single'];
}else{
	$modus_layout_single_port = $modus_config['single_portfolio_type'];
}
$show_title = 'show';
$page_show_breadcrumb = 'show'; 

?>
	<div id="primaryzz" class="content-area">
		<main id="main" class="blog site-main" role="main">
			<?php if($show_title == 'show' && $page_show_breadcrumb == 'show' ):?>
				<div class="breadcrumb-container">
					<div class="bottom-breadcrumb">
						<div class=" container">
							<?php if($show_title == 'show'){ ?>
							<div class="page-title">
								<h2><?php echo get_the_title(); ?></h2>
							</div>
							<?php } ?>			
							<?php if ( $page_show_breadcrumb == 'show' ) { ?>
							<div class="bread-crumb">
								<?php echo modus_breadcrumbs(); ?>
							</div> 
							<?php } ?>
						</div>
					</div>	
				</div>	
			<?php endif;?>			
			<div class="container">
				<div>
					<div>
						<?php if ( have_posts() ) : ?>
							<?php
							// Start the Loop.
							while ( have_posts() ) : the_post();
								// Include the single post content template.
								switch ( $modus_layout_single_port ) {
			                        case 'layout1':
			                            get_template_part( 'template-parts/portfolio/content', 'single-portfolio-layout1' );
			                            break;
			                        case 'layout2':
			                            get_template_part( 'template-parts/portfolio/content', 'single-portfolio-layout2' );
			                            break;
                					case 'layout3':
			                            get_template_part( 'template-parts/portfolio/content', 'single-portfolio-layout3' );
			                            break;
			                        default:
			                            get_template_part( 'template-parts/portfolio/content', 'single-portfolio-layout1' );
			                            break;
			                    }
			                    
			                    ?>
			                     <div class="port-single-bottom">			                       
		                            <div class="row">
		                                <div class="col-xs-12">
		                                    <?php
		                                    modus_post_nagivation( array(
		                                        'post_type_link' => get_post_type_archive_link('portfolio'),
		                                        'container_class'   => '',
		                                        'prev_link_class'   => 'prev',
		                                        'next_link_class'   => 'next',
		                                        'prev_link_before'  => '<i class="fa fa-angle-left"></i>'.esc_html__('Older posts','modus'),
		                                        'next_link_after'   => esc_html__('newer posts','modus').'<i class="fa fa-angle-right"></i>',
		                                    ) );
		                                    ?>
		                                </div>
		                            </div>			                        
			                    </div>
			                <?php
							endwhile;	
						endif;
						?>
					</div>					
				</div>
			</div>
		</main><!-- .site-main -->
	</div><!-- .content-area -->
<?php get_footer(); ?>
