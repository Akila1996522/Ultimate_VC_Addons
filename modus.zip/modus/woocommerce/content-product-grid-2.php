<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $woocommerce,$product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<div class="item-grid grid-type2">
    <div <?php post_class(); ?>>
        <div class="product-thumbnails">
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('modus-blog-3'); ?></a>
            <div class="btn-cart-in">
                <div class="midle">
                    <div class="share-yith">
						<div class="btn-share btn-addtocart">
							<?php woocommerce_template_loop_add_to_cart();?>
						</div>
                        <?php
							modus_share_yith();
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="info-bottom">
            <div class="ct-product-right">
                <a href="<?php the_permalink(); ?>"><?php echo woocommerce_template_loop_product_title(); ?></a>
                <div class="price-product">
					
					 <?php if(null!==get_post_meta( $product->get_id(), '_unit_price', true )&&get_post_meta( $product->get_id(), '_unit_price', true )!=''): ?>
						
					 <?php endif; ?>
                    <?php
                    $rating_count = $product->get_rating_count();
                    $review_count = $product->get_review_count();
                    $average      = $product->get_average_rating();
                    if ( $rating_count > 0 ) : ?>
                        <div class="rated">
                            <div class="star-rating">
                                <span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%"></span>
                            </div>
                        </div>
                    <?php endif;
                    if ( $rating_count == 0 ) :
                        ?>
                        <div class="rated">
                            <div class="star-rating">
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>