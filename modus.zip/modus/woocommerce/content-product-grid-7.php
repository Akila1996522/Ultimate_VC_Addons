<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<div class="item-grid grid-type7">
	<div <?php post_class(); ?>>
		<div class="product-thumbnails">
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'modus-blog-3' ); ?></a>
			<?php
				if(class_exists( 'YITH_WCQV')){
					echo '<div class="quickview"><div class="midle"><div class="btn-share btn-view">';
					printf('<div class="add-to"><a onclick="" href="#" class="yith-wcqv-button button" data-toggle="tooltip" data-product_id="%d" title="%s"><i class="Pe-icon-7-stroke-search"></i></a></div>', get_the_ID(), esc_html__('Quick View', 'modus'));
					echo '</div></div></div>';
				}
			?>
		</div>
		<div class="info-bottom text-center">
			<div class="ct-product-right">
				<a href="<?php the_permalink(); ?>"><?php echo woocommerce_template_loop_product_title(); ?></a>
			    <div class="price-product">
					 <?php echo woocommerce_template_loop_price();?>
					 <?php if(null!==get_post_meta( $product->get_id(), '_unit_price', true )&&get_post_meta( $product->get_id(), '_unit_price', true )!=''): ?>
					
					 <?php endif; ?>
				</div>
			</div>
			<div class="share-yith">
				<div class="midle">
					<div class="btn-share btn-addtocart">
						<?php woocommerce_template_loop_add_to_cart(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>