<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

while ( have_posts() ) : the_post(); 
	global $product;
	?>

 <div class="product">

	<div id="product-<?php the_ID(); ?>" <?php post_class('product'); ?>>
		<div class="col-md-5">	
			<?php //do_action( 'yith_wcqv_product_image' ); ?>
			<div class="product-thum">
                <!-- Place somewhere in the <body> of your page -->
                <div id="slider" class="flexslider">
                  <ul class="slides">
                    <li><div class="border"><?php the_post_thumbnail('full');?></div></li>
                    <?php
                    $attachment_ids = $product->get_gallery_image_ids();
                    ?>
                    <?php
                    if ( $attachment_ids && has_post_thumbnail() ) {
                        foreach ( $attachment_ids as $attachment_id ) {
                            $thumbnail       = wp_get_attachment_image_src( $attachment_id, 'full' );
                            ?>
                            <li><div class="border"><img src="<?php echo esc_url( $thumbnail[0] ); ?>" /></div></li>
                        <?php
                        }
                    }
                    ?>
                  </ul>
                </div>
                <div id="carousel" class="flexslider">
                    <ul class="slides">
                        <li><div class="border"><?php the_post_thumbnail('modus-image-product-thumnail');?></div></li>
                        <?php
                        $attachment_ids = $product->get_gallery_image_ids();
                        ?>
                        <?php
                        if ( $attachment_ids && has_post_thumbnail() ) {
                            foreach ( $attachment_ids as $attachment_id ) {
                                $thumbnail       = wp_get_attachment_image_src( $attachment_id, 'modus-image-product-thumnail' );
                                ?>
                                <li><div class="border"><img src="<?php echo esc_url( $thumbnail[0] ); ?>" /></div></li>
                            <?php
                            }
                        }
                        ?>
                  </ul>
                </div>
            </div>
		</div>
		<div class="col-md-7">
			<div class="summary entry-summary">
				<div class="summary-content">
					<?php do_action( 'yith_wcqv_product_summary' ); ?>
				</div>
			</div>
		</div>

	</div>

</div>

<?php endwhile; // end of the loop.
?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/flexslider.css">
<script type="text/javascript">
	    /*Cart js*/
    var q = jQuery('.quantity');
    q.on('click','button',function(e){
        e.preventDefault();
        var self = jQuery(this),
        data = self.data('count'),
        i = self.parent().children('input'),
        val = i.val();
        if(data === "plus"){
                i.val(++val);
        }
        else{
                if(val == 1) return false;
                i.val(--val);
        }
        jQuery( document ).on(
        'change input',
        'div.woocommerce > form .cart_item :input',
        jQuery( 'div.woocommerce > form input[name="update_cart"]' ).prop( 'disabled', false ) );
    });


    jQuery( document ).ready( function($){
        if ( jQuery('#carousel').length ) {
            var $_width = (jQuery('#carousel').width()) /4;
            jQuery('#carousel').flexslider({
                animation: "slide",
                controlNav: false,
                animationLoop: false,
                slideshow: false,
                itemWidth: $_width,
                itemMargin: 0,
                asNavFor: '.flexslider'
            });
        }
    });
    jQuery('.flexslider').flexslider({
	    animation: "slide",
	    controlNav: false,
	    animationLoop: false,
	    slideshow: false,
	    sync: "#carousel"
	});
</script>