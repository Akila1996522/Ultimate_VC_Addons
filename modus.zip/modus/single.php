<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage modus
 */

get_header();
$modus_sidebar_position = 'left';
$padding_top = '';
$padding_bottom = '';
$modus_config = modus_settings();
if(isset($modus_config['post_sidebar_position'])){
	$modus_sidebar_position = $modus_config['post_sidebar_position'];
}
if(isset($modus_config['post_sidebar'])){
	$modus_sidebars = $modus_config['post_sidebar'];
	if(!is_active_sidebar($modus_sidebars)){
		$modus_sidebar_position = 'none'; 
	}
}
if(isset($_GET['modus_sidebar_position']) && $_GET['modus_sidebar_position']=='none'){
	$modus_sidebar_position='none';
}
if ( get_post_meta(get_the_ID(), 'no_padding_top', true) != ''){

	$padding_top = get_post_meta(get_the_ID(), 'no_padding_top', true);
}
if ( get_post_meta(get_the_ID(), 'no_padding_bottom', true) != ''){
	$padding_bottom = get_post_meta(get_the_ID(), 'no_padding_bottom', true);
}

if($modus_sidebar_position == 'left-sidebar' ){
	$modus_class_sidebar = 'sidebar_left';
	$modus_wrap_content = 'col-xs-12 col-sm-12 col-md-8 col-lg-9 right';
}else if( $modus_sidebar_position == 'right-sidebar' ){
	$modus_class_sidebar = 'sidebar_right';
	$modus_wrap_content = 'col-xs-12 col-sm-12 col-md-8 col-lg-9';
}else{
	$modus_wrap_content='col-xs-12 col-sm-12 col-md-12';
} 
$blog_show_breadcrum = 'hide';
if ( isset( $modus_config['archive_blog_banner'] ) ) $blog_show_breadcrum = $modus_config['archive_blog_banner'];
$show_title = 'show';
?>
	<div id="primary" class="content-area">
		<main id="main" class="blog site-main<?php if ( $blog_show_breadcrum == 'hide' ) echo ' padding-top-60'; ?>" role="main">
			<?php if($show_title == 'show' && $blog_show_breadcrum == 'show' ):?>
				<div class="breadcrumb-container">
					<div class="bottom-breadcrumb">
						<div class=" container">
							<?php if($show_title == 'show'){ ?>
							<div class="page-title">
								<h2><?php echo get_the_title(); ?></h2>
							</div>
							<?php } ?>			
							<?php if ( $blog_show_breadcrum == 'show' ) : ?>					
								<div class="bread-crumb">
									<?php echo modus_breadcrumbs(); ?>
								</div>
							<?php endif; ?>
						</div>
					</div>	
				</div>	
			<?php endif;?>	
			<div class="container">
				<div class="row">
					<div class="<?php echo esc_attr($modus_wrap_content); ?>">
						<?php if ( have_posts() ) : ?>
							<?php
							// Start the Loop.
							while ( have_posts() ) : the_post();
								// Include the single post content template.
								get_template_part( 'template-parts/content', 'single' ); 
							endwhile;
						// If no content, include the "No posts found" template.
						else :
							get_template_part( 'template-parts/content', 'none' );

						endif;
						?>
					</div>
					<?php
					if( $modus_sidebar_position != 'none' && $modus_sidebar_position != '' ){ ?>
						<div class="col-xs-12 col-sm-12 col-md-4 col-lg-3 <?php echo esc_attr( $modus_class_sidebar ); ?>">
							<div class="sidebar sidebarArea sidebar-blog">
								<?php dynamic_sidebar($modus_sidebars ); ?>
							</div>
						</div>
					<?php
						}
					?>
				</div>
			</div>
		</main><!-- .site-main -->
	</div><!-- .content-area -->
<?php get_footer(); ?>
