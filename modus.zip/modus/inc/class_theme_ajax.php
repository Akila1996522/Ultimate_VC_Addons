<?php
/**
 * Ajax handler for the theme
 * @package modus
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Cheatin\' huh?' );
}


