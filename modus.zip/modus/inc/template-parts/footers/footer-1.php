<?php $modus_config = modus_settings();
?>
<div id="foodter_v1" class="footer footer-v1">
	<?php if( $modus_config['footer_1_top']=='show' && is_active_sidebar('footer-top-1')){
		echo '<div class="footer-tops footer-top-1"><div class="container">';
			dynamic_sidebar( 'footer-top-1' );
		echo '</div></div>';
		}
	?>
	<?php if ( $modus_config['footer_1_center']=='show' ) : ?>
		<div class="container">
			<?php if( is_active_sidebar('footer-center')){
				echo '<div class="footer-center padding-bottom-100">';
				dynamic_sidebar( 'footer-center' );
				echo '</div>';
			} ?>
			<?php 
		        $cols = 0;
		        for ($i = 1; $i <= 5; $i++) {
		            if (is_active_sidebar('footerv1-menu' . $i))
		                $cols++;
		        }
		    ?>
			<?php
		        if ($cols) :
		            $col_class = array();
		            switch ($cols) {
		                case 1:
		                    $col_class[1] = 'col-sm-12 text-center';
		                    break;
		                case 2:
		                    $col_class[1] = 'col-sm-12 col-xs-6 col-md-6';
		                    $col_class[2] = 'col-sm-12 col-xs-6 col-md-6';
		                    break;
		                case 3:
		                    $col_class[1] = 'col-xs-12 col-sm-4 col-md-4';
		                    $col_class[2] = 'col-xs-12 col-sm-4 col-md-4';
		                    $col_class[3] = 'col-xs-12 col-sm-4 col-md-4';
		                    break;
		                case 4:
		                    $col_class[1] = 'col-md-5 col-sm-12 col-xs-12';
		                    $col_class[2] = 'col-md-2 col-sm-4 col-xs-12';
		                    $col_class[3] = 'col-md-2 col-sm-4 col-xs-12';
		                    $col_class[4] = 'col-md-3 col-sm-4 col-xs-12';
		                    break;
		                case 5:
		                    $col_class[1] = 'col-md-3 col-sm-6 col-xs-12';
		                    $col_class[2] = 'col-md-2 col-sm-6 col-xs-12';
		                    $col_class[3] = 'col-md-2 col-sm-6 col-xs-12';
		                    $col_class[4] = 'col-md-2 col-sm-6 col-xs-12';
		                    $col_class[5] = 'col-md-3 col-sm-6 col-xs-12';
		                    break;
		            }
		    ?>
			<div class="footer-top">
    			<div class="row">
                    <?php
                    $cols = 1;
                    for ($i = 1; $i <= 5; $i++) {
                        if (is_active_sidebar('footerv1-menu' . $i)) {
                            ?>
                            <div class="<?php echo esc_attr($col_class[$cols++]) ?>">
                                <?php dynamic_sidebar('footerv1-menu' . $i); ?>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
			</div>
			<?php endif;?>
		</div>
	<?php endif;?>
	<?php if ( $modus_config['footer_1_bottom']=='show' ) : ?>
		<div class="bottom-footer">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-lg-8 col-sm-6 col-xs-12">
						<div class="pull-left footercopyright">
							<?php
								if($modus_config['footer_coppyright'] !=''){
									if(get_option('footer_coppyright')){
										echo wp_kses_post(get_option('footer_coppyright'));
									}else{
											echo wp_kses_post($modus_config['footer_coppyright']);
									}
								}
							?>
						</div>
					</div>
					<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
						<div class="pull-right">
							<?php
								if(isset($modus_config['show_payment']) && $modus_config['show_payment'] =='show' && isset($modus_config['footer_bank']) && $modus_config['footer_bank'] !=''){
									echo wp_kses_post($modus_config['footer_bank']);
								}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div><!-- #header_v1-->
