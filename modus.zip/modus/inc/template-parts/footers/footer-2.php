<?php $modus_config = modus_settings();
?>
<div id="foodter_v2" class="footer footer-v2">
	<?php if ( $modus_config['footer_2_top']=='show' ) : ?>
		<div class="footer-tops">
			<div class="logo-footer">
			<?php
			if ( $modus_config['footer_2_logo'] != '' && isset( $modus_config['footer_2_logo']) ):
				echo '<a href="'.esc_url( home_url( '/' ) ).'">';
				echo '<img src="'. esc_url(str_replace(array('http:', 'https:'), '', $modus_config['footer_2_logo']['url'])) . '" alt="' . esc_attr(get_bloginfo('name', 'display')) . '">';
				echo '</a>';
			else:
				modus_logo();
			endif;
			?>
			</div>
		</div>
	<?php endif;?>
	<?php if ( $modus_config['footer_2_center']=='show' ) : ?>
		<div class="footer-center padding-bottom-100">
			<div class="container">
				<div class="row">
				<?php 
			        $cols = 0;
			        for ($i = 1; $i <= 4; $i++) {
			            if (is_active_sidebar('footerv2-menu' . $i))
			                $cols++;
			        }
			    ?>
				<?php
			        if ($cols) :
			            $col_class = array();
			            switch ($cols) {
			                case 1:
			                    $col_class[1] = 'col-sm-12 text-center';
			                    break;
			                case 2:
			                    $col_class[1] = 'col-sm-12 col-xs-6 col-md-6';
			                    $col_class[2] = 'col-sm-12 col-xs-6 col-md-6';
			                    break;
			                case 3:
			                    $col_class[1] = 'col-xs-12 col-sm-4 col-md-4';
			                    $col_class[2] = 'col-xs-12 col-sm-4 col-md-4';
			                    $col_class[3] = 'col-xs-12 col-sm-4 col-md-4';
			                    break;
			                case 4:
			                    $col_class[1] = 'col-lg-4 col-md-3 col-sm-5 col-xs-12';
			                    $col_class[2] = 'col-lg-2 col-md-3 col-sm-4 col-xs-12';
			                    $col_class[3] = 'col-lg-2 col-md-2 col-sm-3 col-xs-12';
			                    $col_class[4] = 'col-lg-4 col-md-4 col-sm-12 col-xs-12';
			                    break;
			            }
			    ?>
			    <?php
                $cols = 1;
                for ($i = 1; $i <= 4; $i++) {
                    if (is_active_sidebar('footerv2-menu' . $i)) {
                        ?>
                        <div class="<?php echo esc_attr($col_class[$cols++]) ?>">
                            <?php dynamic_sidebar('footerv2-menu' . $i); ?>
                        </div>
                        <?php
                    }
                }
                ?>
                <?php endif; ?>
           		 </div>
			</div>
		</div>
	<?php endif;?>
	<?php if ( $modus_config['footer_2_bottom']=='show' ) : ?>
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-lg-8 col-sm-6 col-xs-12">
						<div class="pull-left footercopyright">
							<?php
								if($modus_config['footer_coppyright'] !=''){
									if(get_option('footer_coppyright')){
										echo wp_kses_post(get_option('footer_coppyright'));
									}else{
											echo wp_kses_post($modus_config['footer_coppyright']);
									}
								}
							?>
						</div>
					</div>
					<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
						<div class="pull-right">
							<?php
								if(isset($modus_config['show_payment']) && $modus_config['show_payment'] =='show' && isset($modus_config['footer_bank']) && $modus_config['footer_bank'] !=''){
									echo wp_kses_post($modus_config['footer_bank']);
								}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div>