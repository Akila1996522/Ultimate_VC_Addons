<?php $modus_config = modus_settings();
?>
<div id="foodter_v7" class="footer footer-v7">
	<?php if ( $modus_config['footer_7_top']=='show' ) : ?>
		<div class="container">
			<div class="row">
				<div class="footer-top">
					<div class="middle-left col-md-5 col-sm-12 col-xs-12">
						
						<?php if(is_active_sidebar('footerv7-menu1')){
							dynamic_sidebar( 'footerv7-menu1' );
						} ?>

						<div class="logo-footer">
							<?php
							if ( $modus_config['footer_7_logo'] != '' && isset( $modus_config['footer_7_logo']) ):
								echo '<a href="'.esc_url( home_url( '/' ) ).'">';
								echo '<img src="'. esc_url(str_replace(array('http:', 'https:'), '', $modus_config['footer_7_logo']['url'])) . '" alt="' . esc_attr(get_bloginfo('name', 'display')) . '">';
								echo '</a>';
							else :
								modus_logo();
							endif;
							?>
						</div>

					</div>
					<div class="col-md-7 col-sm-12 col-xs-12">
						<div class="row">
						<?php 
					        $cols = 0;
					        for ($i = 2; $i <= 4; $i++) {
					            if (is_active_sidebar('footerv7-menu' . $i))
					                $cols++;
					        }
					    ?>
						<?php
					        if ($cols) :
					            $col_class = array();
					            switch ($cols) {
					                case 1:
					                    $col_class[1] = 'col-sm-12 text-center';
					                    break;
					                case 2:
					                    $col_class[1] = 'col-sm-12 col-xs-6 col-md-6';
					                    $col_class[2] = 'col-sm-12 col-xs-6 col-md-6';
					                    break;
					                case 3:
					                    $col_class[1] = 'col-xs-12 col-sm-4 col-md-4';
					                    $col_class[2] = 'col-xs-12 col-sm-4 col-md-4';
					                    $col_class[3] = 'col-xs-12 col-sm-4 col-md-4';
					                    break;
					            }
					    ?>
						<?php
				        $cols = 1;
				        for ($i = 2; $i <= 4; $i++) {
				            if (is_active_sidebar('footerv7-menu' . $i)) {
				                ?>
				                <div class="<?php echo esc_attr($col_class[$cols++]) ?>">
				                    <?php dynamic_sidebar('footerv7-menu' . $i); ?>
				                </div>
				                <?php
				            }
				        }
				        ?>
				        <?php endif;?>
				       	</div>
			   		 </div>
				</div>
			</div>
		</div>
	<?php endif;?>
	<?php if ( $modus_config['footer_7_bottom']=='show' ) : ?>
		<div class="bottom-footer footer_7_bottom">
			<div class="row">
				<div class="container">
					<div class="row">
													<div class="footercopyright" align="center">
								<?php
									if($modus_config['footer_coppyright'] !=''){
										if(get_option('footer_coppyright')){
											echo wp_kses_post(get_option('footer_coppyright'));
										}else{
												echo wp_kses_post($modus_config['footer_coppyright']);
										}
									}
								?>
							</div>
						
						
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div><!-- #header_v1-->
