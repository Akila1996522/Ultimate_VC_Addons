<?php $modus_config = modus_settings();
?>
<div id="foodter_v6" class="footer footer-v6">
	<?php if ( $modus_config['footer_6_center']=='show' ) : ?>
		<div class="container">
			<div class="footer-top">
				<div class="row">
					<?php 
				        $cols = 0;
				        for ($i = 1; $i <= 4; $i++) {
				            if (is_active_sidebar('footerv6-col' . $i))
				                $cols++;
				        }
				    ?>
					<?php
				        if ($cols) :
				            $col_class = array();
				            switch ($cols) {
				                case 1:
				                    $col_class[1] = 'col-sm-12 text-center';
				                    break;
				                case 2:
				                    $col_class[1] = 'col-sm-12 col-xs-6 col-md-6';
				                    $col_class[2] = 'col-sm-12 col-xs-6 col-md-6';
				                    break;
				                case 3:
				                    $col_class[1] = 'col-xs-12 col-sm-4 col-md-4';
				                    $col_class[2] = 'col-xs-12 col-sm-4 col-md-4';
				                    $col_class[3] = 'col-xs-12 col-sm-4 col-md-4';
				                    break;
				                case 4:
				                    $col_class[1] = 'col-md-3 col-sm-6 col-xs-12';
				                    $col_class[2] = 'col-md-3 col-sm-6 col-xs-12';
				                    $col_class[3] = 'col-md-3 col-sm-6 col-xs-12';
				                    $col_class[4] = 'col-md-3 col-sm-6 col-xs-12';
				                    break;
				            }
				    ?>
					<?php
			        $cols = 1;
			        for ($i = 1; $i <= 4; $i++) {
			            if (is_active_sidebar('footerv6-col' . $i)) {
			                ?>
			                <div class="<?php echo esc_attr($col_class[$cols++]) ?>">
			                    <?php dynamic_sidebar('footerv6-col' . $i); ?>
			                </div>
			                <?php
			            }
			        }
			        ?>
			        <?php endif;?>
				</div>
			</div>
		</div>
	<?php endif;?>
	<?php if ( $modus_config['footer_6_bottom']=='show' ) : ?>
		<div class="bottom-footer">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
						<div class="pull-left footercopyright">
							<?php
								if($modus_config['footer_coppyright'] !=''){
									if(get_option('footer_coppyright')){
										echo wp_kses_post(get_option('footer_coppyright'));
									}else{
											echo wp_kses_post($modus_config['footer_coppyright']);
									}
								}
							?>
						</div>
					</div>
					<div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
						<div class="pull-right">
							<?php
								if(isset($modus_config['show_payment']) && $modus_config['show_payment'] =='show' && isset($modus_config['footer_bank']) && $modus_config['footer_bank'] !=''){
									echo wp_kses_post($modus_config['footer_bank']);
								}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div><!-- #header_v1-->
