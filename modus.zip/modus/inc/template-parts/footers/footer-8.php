<?php $modus_config = modus_settings();
?>
<div id="foodter_v8" class="footer footer-v8">
	<div class="footer-top">
		<div class="row">
			<div class="col-xs-12 col-lg-3 col-md-12 col-sm-12">
				<div class="logo-footer">
					<?php
					if ( $modus_config['footer_8_logo'] != '' && isset( $modus_config['footer_8_logo']) ):
						echo '<a href="'.esc_url( home_url( '/' ) ).'">';
						echo '<img src="'. esc_url(str_replace(array('http:', 'https:'), '', $modus_config['footer_8_logo']['url'])) . '" alt="' . esc_attr(get_bloginfo('name', 'display')) . '">';
						echo '</a>';
					else :
						modus_logo();
					endif;
					?>
				</div>
				<?php if(is_active_sidebar('footerv8-menu1')){
					dynamic_sidebar( 'footerv8-menu1' );
				} ?>
			</div>
			<div class="col-xs-12 col-lg-9 col-md-12 col-sm-12 ">
				<div class="row">
				<?php 
			        $cols = 0;
			        for ($i = 2; $i <= 5; $i++) {
			            if (is_active_sidebar('footerv8-menu' . $i))
			                $cols++;
			        }
			    ?>
				<?php
			        if ($cols) :
			            $col_class = array();
			            switch ($cols) {
			                case 1:
			                    $col_class[1] = 'col-sm-12 text-center';
			                    break;
			                case 2:
			                    $col_class[1] = 'col-sm-12 col-xs-6 col-md-6';
			                    $col_class[2] = 'col-sm-12 col-xs-6 col-md-6';
			                    break;
			                case 3:
			                    $col_class[1] = 'col-xs-12 col-sm-4 col-md-4';
			                    $col_class[2] = 'col-xs-12 col-sm-4 col-md-4';
			                    $col_class[3] = 'col-xs-12 col-sm-4 col-md-4';
			                    break;
			                case 4:
			                    $col_class[1] = 'col-md-3 col-sm-6 col-xs-12';
			                    $col_class[2] = 'col-md-3 col-sm-6 col-xs-12';
			                    $col_class[3] = 'col-md-2 col-sm-6 col-xs-12';
			                    $col_class[4] = 'col-md-4 col-sm-6 col-xs-12';
			                    break;
			            }
			    ?>
				<?php
		        $cols = 1;
		        for ($i = 2; $i <= 5; $i++) {
		            if (is_active_sidebar('footerv8-menu' . $i)) {
		                ?>
		                <div class="<?php echo esc_attr($col_class[$cols++]) ?>">
		                    <?php dynamic_sidebar('footerv8-menu' . $i); ?>
		                </div>
		                <?php
		            }
		        }
		        ?>
		        <?php endif;?>
		   		</div>
	    	</div>
		</div>
	</div>
</div><!-- #header_v1-->
