<?php $modus_config = modus_settings();
?>
<div id="foodter_v10" class="footer footer-v10">
	<div class="container">
		<div class="bottom-footer">
			<div class="row">
				<div class="col-md-8 col-lg-8 col-sm-8 col-xs-12">
					<div class="pull-left footercopyright">
						<?php
							if($modus_config['footer_coppyright'] !=''){
								if(get_option('footer_coppyright')){
									echo wp_kses_post(get_option('footer_coppyright'));
								}else{
										echo wp_kses_post($modus_config['footer_coppyright']);
								}
							}
						?>
					</div>
				</div>
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="pull-right">
						<?php if(is_active_sidebar('footerv10-social')){
								dynamic_sidebar( 'footerv10-social' );
							} ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>