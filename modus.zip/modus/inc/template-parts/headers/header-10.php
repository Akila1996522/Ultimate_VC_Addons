<div class="header-v10  <?php echo esc_attr(modus_header_fixed())?>">
<?php $modus_config = modus_settings(); ?>
	<div id="header_v10" class="header header-v10">
		<div class="header-fullwidth">
			<div class="header_wrap">
				<div class="row header-center cl-table">
					<div class="logo col-md-4 col-sm-6 col-xs-5">
						<div class="menu-dropdown">
							<a class="menu-bar" href="#"><i class="pe-7f-menu fa-lg"></i></a>
							<div class="main-nav">
								<div class="hidden-xs hidden-sm">
									<div class="main-navigation">
										<?php
											if ( $modus_config['header_10_menu'] != '' ){
												$menu_id = $modus_config['header_10_menu'];
											}else{
												$menu_id = '';
											}
											if ( $menu_id == '' ) :
												if ( has_nav_menu( 'primary' ) ) :
													wp_nav_menu( array(
														'theme_location' => 'primary',
														'menu_class'     => 'primary-menu',
													) );
												endif;
											else:
												wp_nav_menu( array(
													'menu'    => $menu_id,
													'title_li'          => '',
													'menu_class'        => 'primary-menu',
												) );
											endif;
										?>
									</div>
									<?php
									if ( is_active_sidebar('home10-menu') ){
										dynamic_sidebar( 'home10-menu' );
									}
									?>
								</div>
								<div class="hidden-md hidden-lg">
									<div class="box-mobile text-left">
										<div class="box-tab">
											<div class="widget-heading">
												<h3 class="widget-title"><?php echo esc_html('Menu','modus'); ?></h3>
												<a href="#" class="widget-close"><?php echo esc_html('close','modus'); ?></a>
											</div>
											<div class="boxtab tab1 active">
												<div class="main-navigation">
													<?php
														if ( $modus_config['header_10_menu'] != '' ){
															$menu_id = $modus_config['header_10_menu'];
														}else{
															$menu_id = '';
														}
														if ( $menu_id == '' ) :
															if ( has_nav_menu( 'primary' ) ) :
																wp_nav_menu( array(
																	'theme_location' => 'primary',
																	'menu_class'     => 'primary-menu',
																) );
															endif;
														else:
															wp_nav_menu( array(
																'menu'    => $menu_id,
																'title_li'          => '',
																'menu_class'        => 'primary-menu',
															) );
														endif;
													?>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php $is_home_page = get_post_meta( get_the_ID(),'is_home_page',true); ?>
						<?php if ( is_front_page()  || $is_home_page  ) : ?>
							<h1 class="logo_home">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</h1>
						<?php else:?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<?php modus_logo(); ?>
							</a>
						<?php endif;?>
					</div>
					<div class="right col-md-8 col-sm-3 col-xs-7 text-right">
						<div class="mini-cart">
							<div class="menu-button">
								<button class="btn-responsive-nav"><i class="fa fa-bars fa-lg"></i></button>
								<div class="close-menu"></div>
							</div>
							<div class="inline icon-search">
								<div class="hidden-xs hidden-sm">
									<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
									    <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Enter your keyword...', 'placeholder', 'modus' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
										<button type="submit" class="search-submit"><i class="Pe-icon-7-stroke-search"></i></button>
									</form>
								</div>
								<div class="hidden-md hidden-lg">
									<div class="dropdown">
										<button class="dropdown-toggle" type="button" data-toggle="dropdown" >
											<i class="icon-search3"></i>
										</button>
										<div class="dropdown-menu">
											<div class="search-popup">
												<?php echo get_search_form();?>
											</div>
										</div>
									</div>
								</div>
							</div>
							<?php if( isset($modus_config['header_10_account']) && $modus_config['header_10_account'] =='show'){?>
								<?php if (class_exists('Woocommerce')) { ?>
									<div class="inline user-guest"> 
											<a href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id')) ;?>"><i class="Pe-icon-7-stroke-user"></i></a>
										<?php if ( !is_user_logged_in() ) { ?>
											<div class="login-popup"> 
												<h3 class="login-title"><span><?php esc_html_e('Sign in','modus')?></span><a class="create-account-link" href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id'));?>"><?php esc_html_e('Create an Account','modus')?></a></h3> 
												<?php
													woocommerce_login_form(); 
												?>
											</div>  
										<?php } ?>
									</div>
								<?php } ?>
							<?php }?>
							<?php if( isset($modus_config['header_10_cart']) && $modus_config['header_10_cart'] =='show'){?>
								<div class="inline right">
									<?php
										if(function_exists('modus_header_minicart')) modus_header_minicart();
									?>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- #header_v9-->
</div>
