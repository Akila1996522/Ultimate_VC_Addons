<div class="header_1 <?php echo esc_attr(modus_header_fixed())?>">
<?php 
	$modus_config = modus_settings();  
	if( $modus_config['modus_support'] !=''){
		if(get_option('modus_support')){
			$modus_support = get_option('modus_support');
		}else{
			$modus_support = $modus_config['modus_support'];
		}
	}
?>
<?php if( isset($modus_config['header_1_topbar_show']) && $modus_config['header_1_topbar_show'] =='show'){?>
	<div class="header-top header1-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-4 col-sm-4 col-xs-5 col-left">
					<ul class="nav-social">
						<?php
						$modus_social_array=array(
							'facebook' 			=>'fa-facebook',
							'twitter' 			=>'fa-twitter',
							'google-plus' 		=>'fa-google-plus',
							'pinterest' 		=>'fa-pinterest-p',
							'instagram' 		=>'fa-instagram',
							'dribbble' 			=>'fa-dribbble',
							'flickr' 			=>'fa-flickr',
							'linkedin' 			=>'fa-linkedin',
							'behance' 			=>'fa-behance',
						);
						foreach($modus_social_array as $key => $value){
							if ( $modus_config['social_'.$key.'_link'] != '' ) :
								echo '<li><a href="'.$modus_config['social_'.$key.'_link'].'"><i class="fa '.$value.'" aria-hidden="true"></i></a></li>';
							endif;
						}
						?>
					</ul>
				</div>
				<div class="col-lg-6 col-md-8 col-sm-8 col-xs-7 col-right">
					<ul class="nav-mail-hourse">
						<?php if ( $modus_config['modus_mail'] != '' ) : ?><li>
							<a href="mailto:<?php echo esc_attr($modus_config['modus_mail']); ?>">
								<i class="Pe-icon-7-stroke-mail"></i><?php echo esc_html($modus_config['modus_mail']); ?>
							</a>
							</li><?php endif; ?>
						<?php if ( $modus_config['modus_time'] != '' ) : ?><li><i class="Pe-icon-7-stroke-clock"></i><?php echo wp_kses($modus_config['modus_time'],array(
								'span' => array(),
							))?></li><?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
	<div id="header_v1" class="header header-v1">
		<div class="container"> 
			<div class="header_wrap">
				<div class="header-center cl-table">
					<div class="logo left">
						<?php $is_home_page = get_post_meta( get_the_ID(),'is_home_page',true); ?>
						<?php if ( is_front_page()  || $is_home_page  ) : ?>
							<h1 class="logo_home">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</h1>
						<?php else:?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<?php modus_logo(); ?>
							</a>
						<?php endif;?>
					</div>
					<div class="main-nav">			
						<div class="close-menu"><i class="fa fa-close"></i></div>
						<div class="main-navigation">
							<?php
								if ( $modus_config['header_1_menu'] != '' ){
									$menu_id = $modus_config['header_1_menu'];
								}else{
									$menu_id = '';
								}
								if ( $menu_id == '' ) :
									if ( has_nav_menu( 'primary' ) ) :
										wp_nav_menu( array(
											'theme_location' => 'primary',
											'menu_class'     => 'primary-menu',
										) );
									else: 
										wp_nav_menu( array(
											'menu_class'     => 'primary-menu',
										) );
									endif;
								else:
									wp_nav_menu( array(
										'menu'    => $menu_id,
										'title_li'          => '',
										'menu_class'        => 'primary-menu',
									) );
								endif;
							?>
						</div>
					</div>
					<div class="mini-cart"> 
						<?php if( isset($modus_config['header_1_account']) && $modus_config['header_1_account'] =='show'){?>
							<?php if (class_exists('Woocommerce')) { ?>
								<div class="user-guest"> 
										<a href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id')) ;?>"><i class="icon-user-1"></i></a>
									<?php if ( !is_user_logged_in() ) { ?>
										<div class="login-popup"> 
											<h3 class="login-title"><span><?php esc_html_e('Sign in','modus')?></span><a class="create-account-link" href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id'));?>"><?php esc_html_e('Create an Account','modus')?></a></h3> 
											<?php
												woocommerce_login_form(); 
											?>
										</div>  
									<?php } ?>
								</div>
								<?php } ?>
						<?php } ?>
						<div class="menu-button"> 
							<button class="btn-responsive-nav"><i class="fa fa-bars fa-lg"></i></button>
						</div>
						<?php if( isset($modus_config['header_1_cart']) && $modus_config['header_1_cart'] =='show'){?>
							<div class="close-menu"></div>
							<?php
								if(function_exists('modus_header_minicart')) modus_header_minicart();
							?>
						<?php } ?>
					</div>
				</div>
			</div> 
			
		</div> 
		<div class="header_v1_bottom">
			<div class="container">
				<div class="row header-bottom">
					<?php 
						if($modus_config['header_1_topbar_support'] == 'hide'){
						echo '<div class="col-md-12 col-sm-12 col-xs-12">';
						}else{
						echo '<div class="col-md-9 col-sm-8 col-xs-12">';
						}
					?>
					
						<div class="header1-search">
							<?php
								if(function_exists('modus_header_search')) modus_header_search();
							?>
						</div> 
					</div>
					<?php 
					if($modus_config['header_1_topbar_support'] == 'show'){
					?>
					<div class="col-md-3 col-sm-4 col-xs-12">
						
						<div class="support247">
							<i class="Pe-icon-7-stroke-headphones"></i>
							<div class="header-support">
								<p class="sp1"> <?php echo esc_html($modus_support); ?></p>
								<p class="sp2"><span><?php echo esc_html__('Hotline','modus');?>:</span> <a href="callto:<?php echo esc_attr($modus_config['modus_phone']); ?>"><?php echo esc_html($modus_config['modus_phone']); ?></a></p>
							</div>
						</div>
					</div>
					
					<?php } ?>
				</div>
		</div>
	</div><!-- #header_v1-->
</div>
