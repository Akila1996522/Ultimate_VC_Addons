<div class="header_7 <?php echo esc_attr(modus_header_fixed())?>">
<?php $modus_config = modus_settings(); ?>
<?php if( isset($modus_config['header_7_topbar_show']) && $modus_config['header_7_topbar_show'] =='show'){?>
	<div class="header-top header7-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-3 col-sm-3 col-xs-6 col-left">
					<ul class="nav-social">
						<?php
						$modus_social_array=array(
							'facebook' 			=>'fa-facebook',
							'twitter' 			=>'fa-twitter',
							'google-plus' 		=>'fa-google-plus',
							'pinterest' 		=>'fa-pinterest-p',
							'instagram' 		=>'fa-instagram',
							'dribbble' 			=>'fa-dribbble',
							'flickr' 			=>'fa-flickr',
							'linkedin' 			=>'fa-linkedin',
							'behance' 			=>'fa-behance',
						);
						foreach($modus_social_array as $key => $value){
							if ( $modus_config['social_'.$key.'_link'] != '' ) :
								echo '<li><a href="'.$modus_config['social_'.$key.'_link'].'"><i class="fa '.$value.'" aria-hidden="true"></i></a></li>';
							endif;
						}
						?>
					</ul>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 hidden-xs col-center">
					<ul class="header_7_center">
						<?php if ( $modus_config['modus_phone'] != '' ) : ?>
							<li><?php esc_html_e( 'Hotline: ', 'modus' ); ?>
								<a href="callto:<?php echo esc_attr($modus_config['modus_phone']); ?>"> <?php echo esc_html($modus_config['modus_phone']); ?> </a>
							</li><?php endif; ?>
						<?php if ( $modus_config['modus_mail'] != '' ) : ?>
							<li><?php esc_html_e( 'Email: ', 'modus' ); ?>
								<a href="mailto:<?php echo esc_attr($modus_config['modus_mail']); ?>"> <?php echo esc_html($modus_config['modus_mail']); ?></a>
							</li><?php endif; ?>
					</ul>
				</div>
				<div class="col-lg-4 col-md-3 col-sm-3 col-xs-6 col-right">
					<div class="right">
						<div class="mini-cart">
							<?php if( isset($modus_config['header_7_account']) && $modus_config['header_7_account'] =='show'){?>
								<?php if (class_exists('Woocommerce')) { ?>
								<div class="inline user-guest"> 
										<a href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id')) ;?>"><i class="icon-user-1"></i></a>
									<?php if ( !is_user_logged_in() ) { ?>
										<div class="login-popup"> 
											<h3 class="login-title"><span><?php esc_html_e('Sign in','modus')?></span><a class="create-account-link" href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id'));?>"><?php esc_html_e('Create an Account','modus')?></a></h3> 
											<?php
												woocommerce_login_form(); 
											?>
										</div>  
									<?php } ?>
								</div>
								<?php } ?>
							<?php }?>
							<div class="inline icon-search">
								<div class="dropdown">
									<button class="dropdown-toggle" type="button" data-toggle="dropdown" >
										<i class="icon-search3"></i>
									</button>
									<div class="dropdown-menu">
										<div class="search-popup">
											<?php echo get_search_form();?>
										</div>
									</div>
								</div>
							</div>
							<?php if( isset($modus_config['header_7_cart']) && $modus_config['header_7_cart'] =='show'){?>
								<div class="inline icon_mini-cart">
									<?php
										if(function_exists('modus_header_minicart')) modus_header_minicart();
									?>
								</div>
							<?php }?>
						</div>
					</div>
				</div> 
			</div>
		</div>
	</div>
<?php } ?>
	<div id="header_v1" class="header header-v1">
		<div class="container">
			<div class="header_wrap">
				<div class="row header-center">
					<div class="col-md-3 col-sm-6 col-xs-6">
						<?php $is_home_page = get_post_meta( get_the_ID(),'is_home_page',true); ?>
						<?php if ( is_front_page()  || $is_home_page  ) : ?>
							<h1 class="logo_home">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</h1>
						<?php else:?>
							<div class="logo">
								<a class="logo-page" href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</div>
						<?php endif;?>
					</div>
					<div class="col-md-9 col-sm-6 col-xs-6 text-right col-menu">
						<div class="main-nav">
							<div class="close-menu"><i class="fa fa-close"></i></div>
							<div class="main-navigation">
								<?php
									if ( $modus_config['header_7_menu'] != '' ){
										$menu_id = $modus_config['header_7_menu'];
									}else{
										$menu_id = '';
									}
									if ( $menu_id == '' ) :
										if ( has_nav_menu( 'primary' ) ) :
											wp_nav_menu( array(
												'theme_location' => 'primary',
												'menu_class'     => 'primary-menu',
											) );
										endif;
									else:
										wp_nav_menu( array(
											'menu'    => $menu_id,
											'title_li'          => '',
											'menu_class'        => 'primary-menu',
										) );
									endif;
								?>
							</div>
						</div>
						<div class="mini-cart hidden-lg hidden-md ">
							<div class="menu-button">
								<button class="btn-responsive-nav"><i class="fa fa-bars fa-lg"></i></button>
							</div>
							<div class="close-menu"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- #header_v1-->
</div>
