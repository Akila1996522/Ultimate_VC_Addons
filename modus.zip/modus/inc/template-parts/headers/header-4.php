<div class=" header_4 <?php echo esc_attr(modus_header_fixed())?>">
<?php $modus_config = modus_settings(); ?>
<?php if( isset($modus_config['header_4_topbar_show']) && $modus_config['header_4_topbar_show'] =='show'){?>
	<div class="header-top header1-top hidden-sm hidden-xs">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-left">
					<ul class="nav-social">
						<?php
						$modus_social_array=array(
							'facebook' 			=>'fa-facebook',
							'twitter' 			=>'fa-twitter',
							'google-plus' 		=>'fa-google-plus',
							'pinterest' 		=>'fa-pinterest-p',
							'instagram' 		=>'fa-instagram',
							'dribbble' 			=>'fa-dribbble',
							'flickr' 			=>'fa-flickr',
							'linkedin' 			=>'fa-linkedin',
							'behance' 			=>'fa-behance',
						);
						foreach($modus_social_array as $key => $value){
							if ( $modus_config['social_'.$key.'_link'] != '' ) :
								echo '<li><a href="'.$modus_config['social_'.$key.'_link'].'"><i class="fa '.$value.'" aria-hidden="true"></i></a></li>';
							endif;
						}
						?>
					</ul>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 col-right">
					<ul class="nav-mail-hourse">
						<?php if ( $modus_config['modus_mail'] != '' ) : ?><li><a href="mailto:<?php echo esc_attr($modus_config['modus_mail'])?>"><i class="Pe-icon-7-stroke-mail"></i><?php echo esc_html($modus_config['modus_mail']); ?></a></li><?php endif; ?>
						<?php if ( $modus_config['modus_time'] != '' ) : ?><li><i class="Pe-icon-7-stroke-clock"></i><?php echo wp_kses($modus_config['modus_time'],array(
								'span' => array(),
							))?></li><?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
	<div id="header_v1" class="header header-v1">
		<div class="container"> 
			<div class="header_wrap">
				<div class="header-center cl-table">
					<div class="logo left">
						<?php $is_home_page = get_post_meta( get_the_ID(),'is_home_page',true); ?>
						<?php if ( is_front_page()  || $is_home_page  ) : ?>
							<h1 class="logo_home">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
									<?php modus_logo(); ?>
								</a>
							</h1>
						<?php else:?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<?php modus_logo(); ?>
							</a>
						<?php endif;?>
					</div>
					<div class="main-nav">			
						<div class="close-menu"><i class="fa fa-close"></i></div>
						<div class="main-navigation">
							<?php
								if ( $modus_config['header_1_menu'] != '' ){
									$menu_id = $modus_config['header_1_menu'];
								}else{
									$menu_id = '';
								}
								if ( $menu_id == '' ) :
									if ( has_nav_menu( 'primary' ) ) :
										wp_nav_menu( array(
											'theme_location' => 'primary',
											'menu_class'     => 'primary-menu',
										) );
									else: 
										wp_nav_menu( array(
											'menu_class'     => 'primary-menu',
										) );
									endif;
								else:
									wp_nav_menu( array(
										'menu'    => $menu_id,
										'title_li'          => '',
										'menu_class'        => 'primary-menu',
									) );
								endif;
							?>
						</div>
					</div>
					<div class="mini-cart"> 
						<?php if( isset($modus_config['header_4_account']) && $modus_config['header_4_account'] =='show'){?>
							<?php if (class_exists('Woocommerce')) { ?>
								<div class="user-guest"> 
										<a href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id')) ;?>"><i class="icon-user-1"></i></a>
									<?php if ( !is_user_logged_in() ) { ?>
										<div class="login-popup"> 
											<h3 class="login-title"><span><?php esc_html_e('Sign in','modus')?></span><a class="create-account-link" href="<?php echo  get_permalink( get_option('woocommerce_myaccount_page_id'));?>"><?php esc_html_e('Create an Account','modus')?></a></h3> 
											<?php
												woocommerce_login_form(); 
											?>
										</div>  
									<?php } ?>
								</div>
							<?php } ?>
						<?php }?>
						<div class="menu-button"> 
							<button class="btn-responsive-nav"><i class="fa fa-bars fa-lg"></i></button>
						</div>
						<div class="close-menu"></div>
						<?php if( isset($modus_config['header_4_cart']) && $modus_config['header_4_cart'] =='show'){?>
							<?php
								if(function_exists('modus_header_minicart')) modus_header_minicart();
							?>
						<?php }?>
					</div>
				</div>
			</div> 
			
		</div> 
	</div><!-- #header_v1-->
</div>
