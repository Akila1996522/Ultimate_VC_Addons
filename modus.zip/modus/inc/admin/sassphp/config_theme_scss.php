<?php
	$config = modus_settings();
?>

//skin
$skinColor: #000;
